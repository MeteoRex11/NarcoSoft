package com.example.hunte.narcosoft_cc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class home_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page);
    }

    public void checkdata(View view)
    {
        Intent i=new Intent(this,data_check.class);
        startActivity(i);
        finish();
    }

    public void report(View view)
    {
        /*Intent i=new Intent(this,report.class);
        startActivity(i);
        finish();*/

        Toast msg = Toast.makeText(home_page.this,"Under Work",Toast.LENGTH_SHORT);
        msg.show();
    }

    public void new_user(View view)
    {
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
        finish();
    }
}
