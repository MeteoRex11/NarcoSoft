package com.example.hunte.narcosoft_cc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class nrnc_list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nrnc_list);
    }
}
