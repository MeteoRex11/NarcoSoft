package com.example.jagma.login_screen;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;

public class MainActivity extends Activity{

    EditText UIDet, Dateet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        UIDet=findViewById(R.id.editText);
        Dateet=findViewById(R.id.editText2);


    }



    public void OnLogin(View view){
        Intent intent = new Intent(this,Main_task_page.class);
        startActivity(intent);
        finish();
        /*String uid = UIDet.getText().toString();
        String date = Dateet.getText().toString();
        String type="login";
        BackgroundWorker backgroundWorker=new BackgroundWorker(this);
        backgroundWorker.execute(type,uid,date);*/

    }
}
