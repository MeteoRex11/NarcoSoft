package com.example.navee.narcosoft_dmt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class nrnc_list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nrnc_list);
    }

    protected void nrnc(Bundle savedInstanceState) {
        Toast msg = Toast.makeText(nrnc_list.this,"Under Work",Toast.LENGTH_SHORT);
        msg.show();
    }
}
