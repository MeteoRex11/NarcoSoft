package com.example.navee.narcosoft_nrnc;

import android.content.Context;
        import android.content.Intent;
        import android.content.SharedPreferences;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;

public class Splash_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_activity);

        SharedPreferences pref= getSharedPreferences("ActivityPref", Context.MODE_PRIVATE);
        if (pref.getBoolean("activity_executed", false)) {
            Intent i =new Intent(this,home_page.class);
            startActivity(i);
            finish();
        }
        else {
            Intent i =new Intent(this,MainActivity.class);
            startActivity(i);
            finish();
        }
    }
}
