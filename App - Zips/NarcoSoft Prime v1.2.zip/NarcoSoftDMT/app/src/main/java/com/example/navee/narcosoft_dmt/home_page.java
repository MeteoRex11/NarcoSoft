package com.example.navee.narcosoft_dmt;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

public class home_page extends AppCompatActivity {

    Startup_BG backgroundWorker = new Startup_BG(this);
    String ROLE = "dmt";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
    }

    public void checkdata(View view)
    {
        Intent i = new Intent(this,location_selection.class);
        startActivity(i);
    }

    public void report(View view)
    {
        /*String role = "report";
        backgroundWorker.execute(ROLE,role);*/

        Intent i = new Intent(this,report_page.class);
        startActivity(i);
    }

    public void new_user(View view)
    {
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
        finish();
    }
}

