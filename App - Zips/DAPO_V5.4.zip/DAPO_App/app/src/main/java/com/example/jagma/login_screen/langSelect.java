package com.example.jagma.login_screen;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.Locale;

public class langSelect extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lang_select);
        final RadioButton lang_en = findViewById(R.id.rb_lang_en);
        final RadioButton lang_pu = findViewById(R.id.rb_lang_pu);
        Button submit = findViewById(R.id.but_lang_sel);

        final SharedPreferences lang_pref= getSharedPreferences("langSel", Context.MODE_PRIVATE);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String lang="en";
                if(lang_en.isChecked()){
                    Toast.makeText(getApplicationContext(),"\' English \' Selected",Toast.LENGTH_SHORT).show();
                    lang="en";
                }
                else if(lang_pu.isChecked()){
                    Toast.makeText(getApplicationContext(),"\' ਪੰਜਾਬੀ \' Selected",Toast.LENGTH_SHORT).show();
                    lang="pa";
                }
                else{
                    Toast.makeText(getApplicationContext(),"Select a Language / ਕੋਈ ਭਾਸ਼ਾ ਚੁਣੋ",Toast.LENGTH_SHORT).show();
                }
                setAppLocale(lang);
                SharedPreferences.Editor edtr =lang_pref.edit();
                edtr.putString("selected_language",lang);
                edtr.apply();
                Log.d("ADebugTag", "Value(langSel): " + lang_pref.getString("selected_language","en"));
                Intent i =new Intent(langSelect.this,MainActivity.class);
                startActivity(i);
                finish();
            }
        });


    }

    public void setAppLocale(String appLocale) {
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1){
            conf.setLocale(new Locale(appLocale.toLowerCase()));
        }
        else{
            conf.locale = new Locale(appLocale.toLowerCase());
        }
        res.updateConfiguration(conf,dm);
    }
}
