package com.example.jagma.login_screen;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class summary extends AppCompatActivity {

    Context context;
    Spinner date_dd;

    TextView d_m_a1, d_i_a1,d_i_a2,d_i_a3 ,d_f_a1,d_f_a2, d_fu_a1,d_fu_a2, p_i_a1,p_i_a2, p_p_a1, a_a1, pa_a1,pa_a2,pa_a3, vs_a1,vs_a2;


    String motivation;
    String month,ID;
    String type="summary";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        date_dd=findViewById(R.id.date_dd);
        context=this;

        d_m_a1=findViewById(R.id.d_m_a1);

        d_i_a1=findViewById(R.id.d_i_a1);
        d_i_a2=findViewById(R.id.d_i_a2);
        d_i_a3=findViewById(R.id.d_i_a3);

        d_f_a1=findViewById(R.id.d_f_a1);
        d_f_a2=findViewById(R.id.d_f_a2);

        d_fu_a1=findViewById(R.id.d_fu_a1);
        d_fu_a2=findViewById(R.id.d_fu_a2);

        p_i_a1=findViewById(R.id.p_i_a1);
        p_i_a2=findViewById(R.id.p_i_a2);

        p_p_a1=findViewById(R.id.p_p_a1);

        a_a1=findViewById(R.id.a_a1);

        pa_a1=findViewById(R.id.pa_a1);
        pa_a2=findViewById(R.id.pa_a2);
        pa_a3=findViewById(R.id.pa_a3);

        vs_a1=findViewById(R.id.vs_a1);
        vs_a2=findViewById(R.id.vs_a2);



        SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(summary.this);
        ID =sharedPreferences.getString("ID","unknown");



        date_dd.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // your code here
                month=date_dd.getSelectedItem().toString();
                AsyncTaskRunner runner = new AsyncTaskRunner();
                String sleepTime = "10";
                runner.execute(sleepTime);


        }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });


    }


    private class AsyncTaskRunner extends AsyncTask<String, String, String> {

        private String resp;
        ProgressDialog progDialog;
        protected ProgressBar mProgressBar;
        private int progressBarStatus = 0;
        String result="";


        @Override
        protected void onPreExecute() {
            progDialog = new ProgressDialog(context);
            progDialog.setMessage("Please wait.");
            progDialog.setCancelable(false);
            progDialog.setIndeterminate(true);
            progDialog.show();
            progressBarStatus = 0;
        }


        @Override
        protected String doInBackground(String... params) {
            String summary_url = "http://115.112.58.50:8097/dapoapi/summary.php";


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(summary_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(5);

                nameValuePairs.add(new BasicNameValuePair("UID", ID));
                nameValuePairs.add(new BasicNameValuePair("month", month));
                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;
        }


        @Override
        protected void onPostExecute(String result) {

            if (progDialog != null) {
                progDialog.dismiss();
                // execution of result of Long time consuming operation



                if (result != null && !result.equals("{}")) {
                    try {
                        System.out.println(result);
                        JSONObject jsonObj = new JSONObject(result);

                        JSONArray jsondistrictarray = jsonObj.getJSONArray("Motivation");
                        for (int i = 0; i < jsondistrictarray.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray.getJSONObject(i);
                            motivation = jsonObjdistrict.getString("Motivation");

                        }
                        d_m_a1.setText(motivation);

                        JSONArray jsondistrictarray2 = jsonObj.getJSONArray("Identification");
                        for (int i = 0; i < jsondistrictarray2.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray2.getJSONObject(i);
                            d_i_a1.setText(jsonObjdistrict.getString("Number_of_Narcotics_Users"));
                            d_i_a2.setText(jsonObjdistrict.getString("Type_of_Drugs_Used"));
                            d_i_a3.setText(jsonObjdistrict.getString("Num_of_Suspect"));

                        }

                        JSONArray jsondistrictarray3 = jsonObj.getJSONArray("Facilitating");
                        for (int i = 0; i < jsondistrictarray3.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray3.getJSONObject(i);
                            d_f_a1.setText(jsonObjdistrict.getString("Number_of_Approached_Victims"));
                            d_f_a2.setText(jsonObjdistrict.getString("Centre_Contacted"));
                        }

                        JSONArray jsondistrictarray4 = jsonObj.getJSONArray("Followup");
                        for (int i = 0; i < jsondistrictarray4.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray4.getJSONObject(i);
                            d_fu_a1.setText(jsonObjdistrict.getString("Drop_Outs_From_Treatment"));
                            d_fu_a2.setText(jsonObjdistrict.getString("Reason_For_Dropping_Out"));
                        }

                        JSONArray jsondistrictarray5 = jsonObj.getJSONArray("VulnerableIden");
                        for (int i = 0; i < jsondistrictarray5.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray5.getJSONObject(i);
                            p_i_a1.setText(jsonObjdistrict.getString("Groups_Identified"));
                            p_i_a2.setText(jsonObjdistrict.getString("Groups_Counseled"));
                        }

                        JSONArray jsondistrictarray6 = jsonObj.getJSONArray("VulnerableProt");
                        for (int i = 0; i < jsondistrictarray6.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray6.getJSONObject(i);
                            p_p_a1.setText(jsonObjdistrict.getString("Protection_of_Vulnerable_Groups"));

                        }

                        JSONArray jsondistrictarray7 = jsonObj.getJSONArray("Awareness");
                        for (int i = 0; i < jsondistrictarray7.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray7.getJSONObject(i);
                            a_a1.setText(jsonObjdistrict.getString("Awareness_Activity_Completion"));

                        }

                        JSONArray jsondistrictarray8 = jsonObj.getJSONArray("Positive");
                        for (int i = 0; i < jsondistrictarray8.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray8.getJSONObject(i);
                            pa_a1.setText(jsonObjdistrict.getString("Positive_Activity_Performed"));
                            pa_a2.setText(jsonObjdistrict.getString("Activity_Venue"));
                            pa_a3.setText(jsonObjdistrict.getString("Problem"));

                        }

                        JSONArray jsondistrictarray9 = jsonObj.getJSONArray("Vigilance");
                        for (int i = 0; i < jsondistrictarray9.length(); i++) {
                            JSONObject jsonObjdistrict = jsondistrictarray9.getJSONObject(i);
                            vs_a2.setText(jsonObjdistrict.getString("Number_Of_Activities_Performed"));
                            vs_a1.setText(jsonObjdistrict.getString("Vigilance_and_Security_Activity"));

                        }









                        // str_chk = "Success";
                    } catch (Exception e) {
                     //   e.printStackTrace();
                    }
                }


            }
        }

    }


}
