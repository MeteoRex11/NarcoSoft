package com.example.jagma.login_screen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class summary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);
    }
}
