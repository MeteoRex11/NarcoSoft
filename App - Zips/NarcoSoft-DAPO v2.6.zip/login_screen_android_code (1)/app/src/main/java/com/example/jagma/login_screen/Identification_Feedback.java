package com.example.jagma.login_screen;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import io.apptik.widget.multiselectspinner.MultiSelectSpinner;

public class Identification_Feedback extends AppCompatActivity {

    EditText d_i_a1, d_i_a2, d_i_a9, d_i_details1, d_i_details2;
    MultiSelectSpinner d_i_a3,d_i_a5,d_i_a6,d_i_a7,d_i_a11,d_i_a12,d_spin_dapo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_identification__feedback);

        d_i_a1 =  findViewById(R.id.d_i_a1);
        d_i_a2 =  findViewById(R.id.d_i_a2);
        //d_i_a3 =  findViewById(R.id.d_i_a3);
        //d_i_a4 = findViewById(R.id.d_i_a4);
        // d_i_a8 =  findViewById(R.id.d_i_a8);
        d_i_a9 =  findViewById(R.id.d_i_a9);
        //d_i_a10 =  findViewById(R.id.d_i_a10);
        d_i_details1 = findViewById(R.id.d_i_details1);
        d_i_details2 = findViewById(R.id.d_i_details2);
        d_spin_dapo=findViewById(R.id.d_spin_dapo);
        d_i_a3 = findViewById(R.id.d_i_a3);
        d_i_a5 = findViewById(R.id.d_i_a5);
        d_i_a6 = findViewById(R.id.d_i_a6);
        d_i_a7 = findViewById(R.id.d_i_a7);
        d_i_a11= findViewById(R.id.d_i_a11);
        d_i_a12 = findViewById(R.id.d_i_a12);



        ArrayList<String> optionsSpin = new ArrayList<>();
        optionsSpin.add("1");
        optionsSpin.add("2");
        optionsSpin.add("3");
        optionsSpin.add("A");
        optionsSpin.add("B");
        optionsSpin.add("C");
        ArrayAdapter<String> adapterSpin = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, optionsSpin);

        d_spin_dapo.setListAdapter(adapterSpin)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All types")
                .setAllUncheckedText("none selected")
                .setSelectAll(false)
                .setTitle("choose")
                .setMinSelectedItems(1);


        ArrayList<String> options3 = new ArrayList<>();
        options3.add("1");
        options3.add("2");
        options3.add("3");
        options3.add("A");
        options3.add("B");
        options3.add("C");
        ArrayAdapter<String> adapter3 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options3);

        d_i_a3.setListAdapter(adapter3)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All types")
                .setAllUncheckedText("none selected")
                .setSelectAll(false)
                .setTitle("choose")
                .setMinSelectedItems(1);


        ArrayList<String> options5 = new ArrayList<>();
        options5.add("1");
        options5.add("2");
        options5.add("3");
        options5.add("A");
        options5.add("B");
        options5.add("C");
        ArrayAdapter<String> adapter5 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options5);

        d_i_a5.setListAdapter(adapter5)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All types")
                .setAllUncheckedText("none selected")
                .setSelectAll(false)
                .setTitle("choose")
                .setMinSelectedItems(1);


        ArrayList<String> options6 = new ArrayList<>();
        options6.add("1");
        options6.add("2");
        options6.add("3");
        options6.add("A");
        options6.add("B");
        options6.add("C");
        ArrayAdapter<String> adapter6 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options6);

        d_i_a6.setListAdapter(adapter6)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All types")
                .setAllUncheckedText("none selected")
                .setSelectAll(false)
                .setTitle("choose")
                .setMinSelectedItems(1);



        ArrayList<String> options7 = new ArrayList<>();
        options7.add("1");
        options7.add("2");
        options7.add("3");
        options7.add("A");
        options7.add("B");
        options7.add("C");
        ArrayAdapter<String> adapter7 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options7);

        d_i_a7.setListAdapter(adapter7)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All types")
                .setAllUncheckedText("none selected")
                .setSelectAll(false)
                .setTitle("choose")
                .setMinSelectedItems(1);


        ArrayList<String> options11 = new ArrayList<>();
        options11.add("1");
        options11.add("2");
        options11.add("3");
        options11.add("A");
        options11.add("B");
        options11.add("C");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options11);

        d_i_a11.setListAdapter(adapter)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All types")
                .setAllUncheckedText("none selected")
                .setSelectAll(false)
                .setTitle("choose")
                .setMinSelectedItems(1);


        ArrayList<String> options12 = new ArrayList<>();
        options12.add("1");
        options12.add("2");
        options12.add("3");
        options12.add("A");
        options12.add("B");
        options12.add("C");
        ArrayAdapter<String> adapter12 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options12);

        d_i_a12.setListAdapter(adapter12)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All types")
                .setAllUncheckedText("none selected")
                .setSelectAll(false)
                .setTitle("choose")
                .setMinSelectedItems(1);





    }
    public void Proceed(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to submit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                        if(connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED)
                        {

                            String Users = d_i_a1.getText().toString();
                            String User_Name = d_i_details1.getText().toString();
                            String User_Address = d_i_a2.getText().toString();
                            //String Narcotics_Type = d_i_a3.getSelectedItem().toString();
                            //String Narcotics_Price =  d_i_a4.getSelectedItem().toString();
                            //String Drug_Abuse_Reason = d_i_a5.getSelectedItem().toString();
                            //String Drug_Abuse_Hotspot = d_i_a6.getSelectedItem().toString();
                            //String Drug_Abusers_Gathering_Areas = d_i_a7.getSelectedItem().toString();
                            //String Supply_Time =  d_i_a8.getText().toString();
                            String Supplier_Name = d_i_details2.getText().toString();
                            String Supplier_Address = d_i_a9.getText().toString();
                            //String Abuse_Time =  d_i_a10.getText().toString();
                            //String Place_Of_Purchase = d_i_a11.getSelectedItem().toString();
                            //String Suggestions = d_i_a12.getText().toString();

                            String type="deaddiction identification";
                            BackgroundWorker backgroundWorker = new BackgroundWorker(Identification_Feedback.this);

                            SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(Identification_Feedback.this);
                            String ID =sharedPreferences.getString("ID","unknown");

                            backgroundWorker.execute(type, Users, User_Name, User_Address,
                                    Supplier_Name, Supplier_Address, ID );

                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"No Internet Connection",Toast.LENGTH_LONG).show();
                            return;
                        }





                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();

    }
}
