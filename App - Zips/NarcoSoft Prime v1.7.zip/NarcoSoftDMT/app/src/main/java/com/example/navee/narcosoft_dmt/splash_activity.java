package com.example.navee.narcosoft_dmt;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.preference.PreferenceManager;

public class splash_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

       /* SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(splash_activity.this);
        String Role_retrieved = sharedPreferences.getString("ROLE","unknown");

        if(Role_retrieved.equals("STF")){		//You can use switch case as well
            //launch STF
            finish();
            return;
        }

        else if(Role_retrieved.equals("DMT")){
            //launch DMT
            return;
        }

        else if(Role_retrieved.equals("SDMT")){
            //launch SDMT
            finish();
            return;
        }

        else if(Role_retrieved.equals("CC")){
            //launch CC
            finish();
            return;
        }

        else if(Role_retrieved.equals("NRNC")){
            //launch NRNC
            finish();
            return;
        }*/


        SharedPreferences pref= getSharedPreferences("ActivityPref", Context.MODE_PRIVATE);

        if (pref.getBoolean("activity_executed", false))
        {
            Intent i =new Intent(this,home_page.class);
            startActivity(i);
            finish();
        }
        else {
            Intent i =new Intent(this,MainActivity.class);
            startActivity(i);
            finish();
        }
    }
}