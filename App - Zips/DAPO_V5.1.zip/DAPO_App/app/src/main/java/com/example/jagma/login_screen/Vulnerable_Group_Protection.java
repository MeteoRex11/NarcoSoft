package com.example.jagma.login_screen;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import io.apptik.widget.multiselectspinner.MultiSelectSpinner;

public class Vulnerable_Group_Protection extends AppCompatActivity {


    MultiSelectSpinner p_p_a1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vulnerable__group__protection);

        p_p_a1 = findViewById(R.id.p_p_a1);

        ArrayList<String> options4 = new ArrayList<>();
        options4.add(getString(R.string.p_a1_eff1));
        options4.add(getString(R.string.p_a1_eff2));
        options4.add(getString(R.string.p_a1_eff3));
        options4.add(getString(R.string.p_a1_eff4));
        options4.add(getString(R.string.p_a1_eff5));
        options4.add(getString(R.string.p_a1_eff6));
        options4.add(getString(R.string.any));

        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options4);

        p_p_a1.setListAdapter(adapter4)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText(getString(R.string.selAll))
                .setAllUncheckedText(getString(R.string.p_a1_prompt))
                .setSelectAll(false)
                .setTitle(getString(R.string.p_a1_prompt))
                .setMinSelectedItems(1); // Spinner 1
    }
    public void Proceed(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getString(R.string.dialog_proceed_head))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        /*Intent i=new  Intent(Vulnerable_Group_Protection.this,Submit_screen.class);
                        startActivityForResult(i,2);
                        finish();*/

                        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                        if(connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED)
                        {

                            String Efforts_For_Protection = p_p_a1.getSelectedItem().toString();
                            String type="vg protection";
                            BackgroundWorker backgroundWorker = new BackgroundWorker(Vulnerable_Group_Protection.this);

                            SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(Vulnerable_Group_Protection.this);
                            String ID =sharedPreferences.getString("ID","unknown");

                            backgroundWorker.execute(type, Efforts_For_Protection, ID);
                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),getString(R.string.noNetConn),Toast.LENGTH_LONG).show();
                            return;
                        }
                    }
                })
                .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}
