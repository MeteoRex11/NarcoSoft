package com.example.jagma.login_screen;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import java.util.ArrayList;

import io.apptik.widget.multiselectspinner.MultiSelectSpinner;

public class Follow_Up_Feedback extends AppCompatActivity {

    MultiSelectSpinner fu_a1,fu_a2,fu_a3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_follow__up__feedback);

        fu_a1=findViewById(R.id.d_fu_a2);
        fu_a2=findViewById(R.id.d_fu_a5);
        fu_a3=findViewById(R.id.d_fu_a6); // Declaration


        ArrayList<String> options2 = new ArrayList<>();
        options2.add("1");
        options2.add("2");
        options2.add("3");
        options2.add("A");
        options2.add("B");
        options2.add("C");
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options2);

        fu_a1.setListAdapter(adapter2)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All Types")
                .setAllUncheckedText("- Specify Reasons -")
                .setSelectAll(false)
                .setTitle("Specify Reasons")
                .setMinSelectedItems(1); // Spinner 1


        ArrayList<String> options3 = new ArrayList<>();
        options3.add("1");
        options3.add("2");
        options3.add("3");
        options3.add("A");
        options3.add("B");
        options3.add("C");
        ArrayAdapter<String> adapter3= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options3);

        fu_a2.setListAdapter(adapter3)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All Types")
                .setAllUncheckedText("- Specify Problems -")
                .setSelectAll(false)
                .setTitle("Specify Problems")
                .setMinSelectedItems(1); // Spinner 2


        ArrayList<String> options4 = new ArrayList<>();
        options4.add("1");
        options4.add("2");
        options4.add("3");
        options4.add("A");
        options4.add("B");
        options4.add("Any Others");
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options4);

        fu_a3.setListAdapter(adapter4)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("Major help required")
                .setAllUncheckedText("- Give Suggestions -")
                .setSelectAll(false)
                .setTitle("Choose Suggestions")
                .setMinSelectedItems(1); // Spinner 3
    }

    public void Proceed(View view){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to submit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        /*Intent i=new  Intent(Facilitation_Feedback.this,Submit_screen.class);
                        startActivityForResult(i,2);
                        finish();*/

                        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                        if(connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED)
                        {

                           //String Victims_Linked_To_Centres = d_f_a1.getText().toString();
                            //String Centre_Contacted =  d_f_a2.getSelectedItem().toString();
                            //String Centre_Issues = d_f_a3.getSelectedItem().toString();
                            //String Drop_Outs = d_f_a4.getText().toString();
                            //String Dropout_Reason = d_f_a5.getSelectedItem().toString();
                            /*String Successfully_Treated =  d_f_a6.getText().toString();
                            String Problems =  d_f_a7.getText().toString();
                            String Suggestions = d_f_a8.getText().toString();*/

                            String type="deaddiction facilitation";
                            BackgroundWorker backgroundWorker = new BackgroundWorker(Follow_Up_Feedback.this);

                            SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(Follow_Up_Feedback.this);
                            String ID =sharedPreferences.getString("ID","unknown");

                            backgroundWorker.execute(type, ID);


                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"No Internet Connection",Toast.LENGTH_LONG).show();
                            return;
                        }






                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();

    }
}
