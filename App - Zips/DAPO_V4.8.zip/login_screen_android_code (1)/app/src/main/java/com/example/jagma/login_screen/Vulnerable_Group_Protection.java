package com.example.jagma.login_screen;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import io.apptik.widget.multiselectspinner.MultiSelectSpinner;

public class Vulnerable_Group_Protection extends AppCompatActivity {


    MultiSelectSpinner p_p_a1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vulnerable__group__protection);

        p_p_a1 = findViewById(R.id.p_p_a1);

        ArrayList<String> options4 = new ArrayList<>();
        options4.add("Counseled the vulnerable regarding ill effects of drugs");
        options4.add("Organised Sports events");
        options4.add("Organised Cultural events");
        options4.add("Promoted Social work");
        options4.add("Organised Spiritual activities");
        options4.add("Gave out pamphlets, films in order to spread awareness");
        options4.add("Any other");

        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options4);

        p_p_a1.setListAdapter(adapter4)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All Types")
                .setAllUncheckedText("- Specify Effort(s) -")
                .setSelectAll(false)
                .setTitle("Specify Effort(s)")
                .setMinSelectedItems(1); // Spinner 1


    }
    public void Proceed(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to submit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        /*Intent i=new  Intent(Vulnerable_Group_Protection.this,Submit_screen.class);
                        startActivityForResult(i,2);
                        finish();*/

                        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                        if(connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED)
                        {

                            String Efforts_For_Protection = p_p_a1.getSelectedItem().toString();
                            String type="vg protection";
                            BackgroundWorker backgroundWorker = new BackgroundWorker(Vulnerable_Group_Protection.this);

                            SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(Vulnerable_Group_Protection.this);
                            String ID =sharedPreferences.getString("ID","unknown");

                            backgroundWorker.execute(type, Efforts_For_Protection, ID);


                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"No Internet Connection",Toast.LENGTH_LONG).show();
                            return;
                        }




                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();

    }
}
