package com.example.navee.narcosoft_dmt;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class info_nrnc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info_nrnc);
    }
}
