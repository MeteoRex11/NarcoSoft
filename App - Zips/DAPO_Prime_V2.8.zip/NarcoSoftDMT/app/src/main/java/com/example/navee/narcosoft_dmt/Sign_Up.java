package com.example.navee.narcosoft_dmt;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Sign_Up extends AppCompatActivity {

    Spinner Role;
    public static final int GET_FROM_GALLERY = 6;
    EditText name,fathname,dob;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign__up);

        Role=findViewById(R.id.role_a1);
        name=findViewById(R.id.sign_a1);
        fathname=findViewById(R.id.sign_a2);
        dob=findViewById(R.id.sign_a3);


    }


    public void proceed(View view){


        String Role_Selected= Role.getSelectedItem().toString().toLowerCase();
        String Name= name.getText().toString().toLowerCase();
        String father= fathname.getText().toString().toLowerCase();
        String Dob= dob.getText().toString().toLowerCase();

        if(Name.isEmpty()){
            Toast.makeText(getApplicationContext(),"Please Enter Name",Toast.LENGTH_LONG).show();
            name.requestFocus();

        }

        else if(father.isEmpty()){
            Toast.makeText(getApplicationContext(),"Please Enter Father's Name",Toast.LENGTH_LONG).show();
            fathname.requestFocus();

        }

        else if(Dob.isEmpty()){
            Toast.makeText(getApplicationContext(),"Please Enter DOB",Toast.LENGTH_LONG).show();
            dob.requestFocus();

        }

        else if(Role_Selected.equals("- choose role -")){
            Toast.makeText(getApplicationContext(),"Please Select Your Role",Toast.LENGTH_LONG).show();
            Role.requestFocus();
        }
        else {
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putString("ROLE", Role_Selected);
            editor.apply();
            Intent intent = new Intent(this, home_page.class);
            startActivity(intent);
            finish();
        }
    }


    public void openGallery(View view){

        startActivityForResult(new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI), GET_FROM_GALLERY);


    }

}
