package com.example.navee.narcosoft_dmt;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.Toast;

public class location_selection extends AppCompatActivity {

    Spinner district,village,mohalla;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.location_selection);

        village = findViewById(R.id.sl_a2);
        mohalla = findViewById(R.id.sl_a3);
        district = findViewById(R.id.sl_a1);

    }

    public void Proceed(View view) {
        String type = "dcheck";
        // Startup_BG backgroundWorker = new Startup_BG(this);
        //backgroundWorker.execute(type);
        String District = district.getSelectedItem().toString().toLowerCase();
        String Village = village.getSelectedItem().toString().toLowerCase();
        String Mohalla = mohalla.getSelectedItem().toString().toLowerCase();


        if (District.equals("- choose location -")) {
            Toast.makeText(getApplicationContext(), "Please Enter District", Toast.LENGTH_LONG).show();
            district.requestFocus();

        }
        else if (Village.equals("- choose location -")) {
            Toast.makeText(getApplicationContext(), "Please Enter Village", Toast.LENGTH_LONG).show();
            village.requestFocus();

        }
        else if (Mohalla.equals("- choose location -")) {
            Toast.makeText(getApplicationContext(), "Please Enter Mohalla", Toast.LENGTH_LONG).show();
            mohalla.requestFocus();

        }
        else {
            SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
            String Role_retrieved = sharedPreferences.getString("ROLE", "unknown");

            if (Role_retrieved.equals("dmt")) {
                Intent i = new Intent(location_selection.this, data_check.class);
                startActivity(i);
                finish();
            } else if (Role_retrieved.equals("sdmt")) {
                Intent i = new Intent(location_selection.this, data_check_sdmt.class);
                startActivity(i);
                finish();
            } else if (Role_retrieved.equals("nrnc")) {
                Intent i = new Intent(location_selection.this, list_dapo.class);
                startActivity(i);
                finish();
            } else if (Role_retrieved.equals("cc")) {
                Intent i = new Intent(location_selection.this, data_check_cc.class);
                startActivity(i);
                finish();
            }
        }
    }
}