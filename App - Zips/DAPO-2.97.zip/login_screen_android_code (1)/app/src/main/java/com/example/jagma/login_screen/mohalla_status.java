package com.example.jagma.login_screen;


import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import java.util.ArrayList;

public class mohalla_status extends AppCompatActivity {

    //private static String TAG ="MainActivity";

    //HARD CODED VALUES TO BE CHANGED AS PER DATABASE

    public int      total_people=1545,
                    healthy=1050,
                    rehab=250,
                    active_users=75,
                    vulnerable=70,
                    unknown=100;

    //PERCENTAGE CALCULATION FOR DISPLAY

    public float hea_mod=((float)healthy*100)/(float)total_people;
    public float rehab_mod=((float)rehab*100)/(float)total_people;
    public float vul_mod=((float)vulnerable*100)/(float)total_people;
    public float active_mod=((float)active_users*100)/(float)total_people;
    public float unknown_mod=((float)unknown*100)/(float)total_people;

    private float[] ydata ={hea_mod,rehab_mod,vul_mod,active_mod,unknown_mod};
    private String[] xdata={"Healthy","Rehabilitation","Vulnerable","Drug Abusers","Unknown"};

    //GLOBAL pieChart
    PieChart pieChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mohalla_status);

        pieChart = (PieChart) findViewById(R.id.pie);

        /*
        //DESCRIPTION
        Description descrip = new Description();
        descrip.setText("Total Registered = "+total_people);
        descrip.setTextSize(15f);
        pieChart.setDescription(descrip);
        pieChart.getDescription().setEnabled(false);
        */

        //PIECHART PROPERTIES
        pieChart.setRotationEnabled(true);
        pieChart.setHoleRadius(50f);
        pieChart.setTransparentCircleAlpha(0);
        pieChart.setCenterText("MOHALLA\nSTATUS\n(Location)");
        pieChart.setCenterTextSize(25f);
        pieChart.spin( 1400,-360f,0f, Easing.EasingOption.EaseInOutQuad);
        //pieChart.animate();
        addDataSet();
    }

    private void addDataSet() {
        ArrayList<PieEntry> yEntrys = new ArrayList<>();
        ArrayList<String> xEntrys = new ArrayList<>();

        for(int i=0;i<ydata.length;i++){
            yEntrys.add(new PieEntry(ydata[i],i));
        }

        for(int i=0;i<xdata.length;i++){
            xEntrys.add(xdata[i]);
        }

        PieDataSet set1 = new PieDataSet(yEntrys,"DAPO");
        set1.setSliceSpace(2);
        set1.setValueTextSize(10);

        ArrayList<Integer> colors = new ArrayList<>();
        //green-healthy
        colors.add(Color.rgb(0,255,0));
        //yellow-rehab
        colors.add(Color.rgb(255,222,32));
        //orange-vul
        colors.add(Color.rgb(255,123,21));
        //red-drugUsers
        colors.add(Color.rgb(255,0,0));
        //grey-unknown
        colors.add(Color.rgb(211,211,211));

        set1.setColors(colors);

        /*
        //LEGEND
        Legend legend = pieChart.getLegend();
        legend.setEnabled(false);
        legend.setForm(Legend.LegendForm.CIRCLE);
        legend.getEntries();
        */

        //object
        PieData pieData = new PieData(set1);
        pieChart.setData(pieData);
        pieData.setValueTextSize(18f);

        //pieData.setValueTextColor(Color.WHITE);

        //pieChart.animate(1400,1400);

        pieChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                //Log.d(TAG,"OnValueSelected: value selected ");
                //Log.d(TAG,"OnValueSelcted: "+ e.toString());
                //Log.d(TAG,"OnValueSelcted: "+ h.toString());
                //Log.d(TAG,"OnValueSelcted: ");

                int pos1=(int)(e.getY()*total_people)/100;
                int stat=(int)h.getX();
                Toast.makeText(mohalla_status.this,"Number of People = " + pos1+" "+xdata[stat],Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected() {
            }
        });
    }
}
;