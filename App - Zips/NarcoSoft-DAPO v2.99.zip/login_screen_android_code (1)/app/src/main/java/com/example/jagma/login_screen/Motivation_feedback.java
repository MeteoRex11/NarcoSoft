package com.example.jagma.login_screen;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

import io.apptik.widget.multiselectspinner.MultiSelectSpinner;

public class Motivation_feedback extends AppCompatActivity {

    EditText d_m_a1,  d_m_a8 ;
    MultiSelectSpinner d_m_a2,d_m_a3,d_m_a4,d_m_a5,d_m_a7, d_m_a6,d_m_a9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motivation_feedback);



        d_m_a1 = findViewById(R.id.d_m_a1);
        d_m_a2 = findViewById(R.id.d_m_a2);
        d_m_a3 = findViewById(R.id.d_m_a3);
        d_m_a4 = findViewById(R.id.d_m_a4);
        d_m_a5 = findViewById(R.id.d_m_a5);
        d_m_a6 = findViewById(R.id.d_m_a6);
        d_m_a7 = findViewById(R.id.d_m_a7);
        d_m_a8 = findViewById(R.id.d_m_a8);
        d_m_a9 = findViewById(R.id.d_m_a9); // Declaration


        ArrayList<String> options2 = new ArrayList<>();
        options2.add("Directly");
        options2.add("Through Friends");
        options2.add("Through Families");
        options2.add("Through Panchayat, and other such organisations");
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options2);

        d_m_a2.setListAdapter(adapter2)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All Types")
                .setAllUncheckedText("- Specify Method -")
                .setSelectAll(false)
                .setTitle("Specify Method of Approach")
                .setMinSelectedItems(1); // Spinner 1


        ArrayList<String> options3 = new ArrayList<>();
        options3.add("1");
        options3.add("2");
        options3.add("3");
        options3.add("A");
        options3.add("B");
        options3.add("C");
        ArrayAdapter<String> adapter3= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options3);

        d_m_a3.setListAdapter(adapter3)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All Types")
                .setAllUncheckedText("- Specify Problems -")
                .setSelectAll(false)
                .setTitle("Specify Problems")
                .setMinSelectedItems(1); // Spinner 2


        ArrayList<String> options4 = new ArrayList<>();
        options4.add("1");
        options4.add("2");
        options4.add("3");
        options4.add("A");
        options4.add("B");
        options4.add("C");
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options4);

        d_m_a4.setListAdapter(adapter4)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All Types")
                .setAllUncheckedText("- Specify Problems -")
                .setSelectAll(false)
                .setTitle("Specify Problems")
                .setMinSelectedItems(1); // Spinner 3


        ArrayList<String> options5 = new ArrayList<>();
        options5.add("1");
        options5.add("2");
        options5.add("3");
        options5.add("A");
        options5.add("B");
        options5.add("C");
        ArrayAdapter<String> adapter5 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options5);

        d_m_a5.setListAdapter(adapter5)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All Types")
                .setAllUncheckedText("- Choose Arguments -")
                .setSelectAll(false)
                .setTitle("Choose Arguments")
                .setMinSelectedItems(1); // Spinner 4


        ArrayList<String> options6 = new ArrayList<>();
        options6.add("1");
        options6.add("2");
        options6.add("3");
        options6.add("A");
        options6.add("B");
        options6.add("C");
        ArrayAdapter<String> adapter6= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options6);

        d_m_a6.setListAdapter(adapter6)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All Types")
                .setAllUncheckedText("- Specify Convincing Factor -")
                .setSelectAll(false)
                .setTitle("Specify Convincing Factor")
                .setMinSelectedItems(1); // Spinner 5


        ArrayList<String> options7 = new ArrayList<>();
        options7.add("Understanding");
        options7.add("Disinterested");
        options7.add("Hostile");
        options7.add("Positive");
        options7.add("Confused");
        options7.add("Resistive");
        ArrayAdapter<String> adapter7 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options7);

        d_m_a7.setListAdapter(adapter2)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("Mixed")
                .setAllUncheckedText("- Choose Attitude -")
                .setSelectAll(false)
                .setTitle("Choose Attitude")
                .setMinSelectedItems(1); // Spinner 6


        ArrayList<String> options9 = new ArrayList<>();
        options9.add("1");
        options9.add("2");
        options9.add("3");
        options9.add("A");
        options9.add("B");
        options9.add("C");
        ArrayAdapter<String> adapter9 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options9);

        d_m_a9.setListAdapter(adapter9)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("Major help required")
                .setAllUncheckedText("- Give Suggestions -")
                .setSelectAll(false)
                .setTitle("Choose Suggestions")
                .setMinSelectedItems(1); // Spinner 7



    }

    public void Proceed(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to submit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        /*Intent i=new  Intent(Motivation_feedback.this,Submit_screen.class);
                        startActivityForResult(i,2);
                        finish();*/

                        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                        if(connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED)
                        {

                            String Victims_Approached = d_m_a1.getText().toString();
                            String Approach_Method = d_m_a2.getSelectedItem().toString();;
                            String Victim_Approach_Problems = d_m_a3.getSelectedItem().toString();
                            String Family_Approach_Problems =  d_m_a4.getSelectedItem().toString();
                            String Arguments = d_m_a5.getSelectedItem().toString();
                            String Convincing_Factor = d_m_a6.getSelectedItem().toString();
                            String Victim_Attitude = d_m_a7.getSelectedItem().toString();
                            String Revisit_Needed = d_m_a8.getText().toString();
                            String Suggestions =  d_m_a9.getSelectedItem().toString();

                            String type="deaddiction motivation";
                            BackgroundWorker backgroundWorker = new BackgroundWorker(Motivation_feedback.this);

                            SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(Motivation_feedback.this);
                            String ID =sharedPreferences.getString("ID","unknown");

                            backgroundWorker.execute(type, Victims_Approached, Approach_Method, Victim_Approach_Problems, Family_Approach_Problems,
                                    Arguments, Convincing_Factor, Victim_Attitude, Revisit_Needed, Suggestions, ID );


                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"No Internet Connection",Toast.LENGTH_LONG).show();
                            return;
                        }



                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();

    }
}
