package com.example.navee.narcosoft_dmt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class data_check_cc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_check_cc);
    }

    public void nrnc(View view)
    {
        Intent i=new Intent(this,list_nrnc.class);
        startActivity(i);
    }

    public void dapo(View view)
    {
        Intent i=new Intent(this,list_dapo.class);
        startActivity(i);
    }

    public void new_user(View view)
    {
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
    }
}
