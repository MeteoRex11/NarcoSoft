package com.example.navee.narcosoft_dmt;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class list_nrnc extends AppCompatActivity {

    int[] Dps = {R.drawable.cj, R.drawable.ryder, R.drawable.smoke, R.drawable.snoop, R.drawable.cj, R.drawable.ryder,
            R.drawable.smoke, R.drawable.snoop, R.drawable.cj, R.drawable.ryder, R.drawable.smoke, R.drawable.snoop};

    String[] nrnc_names = {"CJ", "Ryder", "Big Smoke", "Snoop Dogg", "50 cent", "Tupac", "Lil Wayne",
            "Wiz Khalifa", "Travis Scott", "J Cole"};

    String role = "NRNC";

    String[] location = {" Zirkapur", " Panchkula", " Chandigarh", " Location", " Location", " Location"
            , " Location", " Location", " Location", " Location"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_nrnc);

        SharedPreferences pref = getSharedPreferences("ActivityPref", MODE_PRIVATE);
        SharedPreferences.Editor edt = pref.edit();
        edt.putBoolean("activity_executed", true);
        edt.apply();

        ListView listView = findViewById(R.id.lv_1);

        list_nrnc.CustomAdapter customAdapter = new list_nrnc.CustomAdapter();
        listView.setAdapter(customAdapter);
    }

    public void info_page(View view) {
        Toast msg = Toast.makeText(list_nrnc.this, "Opening...", Toast.LENGTH_SHORT);
        msg.show();
        Intent i = new Intent(this, info_nrnc.class);
        startActivity(i);
    }

    public void new_user(View view) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);
        finish();
    }

    class CustomAdapter extends BaseAdapter {


        @Override
        public int getCount() {
            return nrnc_names.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View convertView, ViewGroup parent) {

            convertView = getLayoutInflater().inflate(R.layout.dapo_list_listview_layout, null);

            TextView dapo_name = convertView.findViewById(R.id.user_1);
            TextView roles = convertView.findViewById(R.id.dapo_loc_ind);
            TextView dapo_location = convertView.findViewById(R.id.location_1);

            ImageView imageView = convertView.findViewById(R.id.dapo_uid_1);

            dapo_name.setText(nrnc_names[i]);
            roles.setText(role);
            dapo_location.setText(location[i]);

            imageView.setImageResource(Dps[i]);


            return convertView;
        }
    }
}
