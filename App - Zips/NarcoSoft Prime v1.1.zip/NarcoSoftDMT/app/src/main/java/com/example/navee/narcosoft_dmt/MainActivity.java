package com.example.navee.narcosoft_dmt;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText UID, MobNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        UID=findViewById(R.id.editText);
        MobNo=findViewById(R.id.editText2);
    }

    public void login(View view){

        String uid = UID.getText().toString();
        String mobno = MobNo.getText().toString();
        String role ="login";


        Intent intent = new Intent(this,home_page.class);
        startActivity(intent);
        finish();

        /*Startup_BG backgroundWorker = new Startup_BG(this);
        backgroundWorker.execute(role,uid,mobno);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("ID", uid);
        editor.apply();

        Intent intent = new Intent(this,home_page.class);
        startActivity(intent);
        finish();*/

    }

}
