package com.example.navee.narcosoft_dmt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class location_selection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.location_selection);
    }

    public void Proceed(View view)
    {
        String type="dcheck";
        Startup_BG backgroundWorker=new Startup_BG(this);
        backgroundWorker.execute(type);
    }
}