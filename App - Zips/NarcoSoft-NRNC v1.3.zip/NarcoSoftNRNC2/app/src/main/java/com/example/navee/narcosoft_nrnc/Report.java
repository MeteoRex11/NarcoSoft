package com.example.navee.narcosoft_nrnc;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class Report extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        /*
        Spinner spinner =(Spinner)findViewById(R.id.spinner_time);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.time_choices,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        */

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        RadioGroup check = (RadioGroup)findViewById(R.id.radio_group_2);
        final EditText official_details = (EditText)findViewById(R.id.editText7);
        official_details.setVisibility(View.GONE);
        check.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(checkedId==R.id.radioButton5){
                    official_details.setVisibility(View.VISIBLE);
                }
                else if(checkedId==R.id.radioButton6){
                    official_details.setVisibility(View.GONE);
                }
            }
        });
    }

}
