package com.example.jagma.login_screen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Follow_Up_Feedback extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_follow__up__feedback);
    }
}
