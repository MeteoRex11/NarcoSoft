package com.example.navee.narcosoft_dmt;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;

public class Sign_Up extends AppCompatActivity {

    Spinner Role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign__up);

        Role=findViewById(R.id.role_a1);

    }

    public void proceed(View view){

        String Role_Selected= Role.getSelectedItem().toString();


        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("ROLE", Role_Selected);
        editor.apply();

        Intent intent= new Intent(this,home_page.class);
        startActivity(intent);
        finish();
    }
}
