package com.example.jagma.login_screen;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.widget.ProgressBar;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BackgroundWorker extends AsyncTask<String,Void,String> {

    Context context;
    AlertDialog alertDialog;
    BackgroundWorker (Context ctx){
        context = ctx;
    }
    String   paramm[];

    protected ProgressBar mProgressBar;
    private int progressBarStatus = 0;
    ProgressDialog progDialog;


    @Override
    protected void onPreExecute() {
        progDialog = new ProgressDialog(context);
        progDialog.setMessage("Please wait.");
        progDialog.setCancelable(false);
        progDialog.setIndeterminate(true);
        progDialog.show();
        progressBarStatus = 0;


    }


    @Override
    protected String doInBackground(String... params) {
        paramm=params;
        String type = params[0];
        String login_url = "http://115.112.58.50:8097/dapoapi/login.php";
        String deaddiction_identification_url = "http://115.112.58.50:8097/dapoapi/deaddiction_identification.php";
        String deaddiction_motivation_url = "http://115.112.58.50:8097/dapoapi/deaddiction_motivation.php";
        String deaddiction_facilitation_url = "http://115.112.58.50:8097/dapoapi/deaddiction_facilitation.php";
        String vg_identification_url = "http://115.112.58.50:8097/dapoapi/Identification_VG.php";
        String vg_protection_url = "http://115.112.58.50:8097/dapoapi/Protection_VG.php";
        String awareness_url = "http://115.112.58.50:8097/dapoapi/Awareness.php";

        String positive_activity_url = "http://115.112.58.50:8097/dapoapi/positive_activity.php";



        String result="";

        if (type.equals("login")) {
            String UID = params[1];
            String mobno = params[2];
            String rand = params[3];


                HttpClient httpclient = new DefaultHttpClient();
                HttpPost httppost = new HttpPost(login_url);
                HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
                HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

                try {
                    List<NameValuePair> nameValuePairs = new ArrayList<>(5);

                    nameValuePairs.add(new BasicNameValuePair("UID", UID));
                    nameValuePairs.add(new BasicNameValuePair("MobNo", mobno));
                    nameValuePairs.add(new BasicNameValuePair("rannd", rand));

                    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    HttpResponse response = httpclient.execute(httppost);
                    String responseBody = EntityUtils.toString(response.getEntity());
                    result = responseBody.trim();
                    Utilities.LogDebug(result);
                } catch (ClientProtocolException e) {
                    Utilities.LogDebug("error " + e.getMessage());
                } catch (IOException e) {
                    Utilities.LogDebug("error " + e.getMessage());
                }
                return result;
        }




        else if(type.equals("deaddiction identification"))
        {
            String Users = params[1];
            String User_Name = params[2];
            String User_Address = params[3];
            String Narcotics_Type = params[4];
            String Narcotics_Price =  params[5];
            String Drug_Abuse_Reason = params[6];
            String Drug_Abuse_Hotspot = params[7];
            String Drug_Abusers_Gathering_Areas = params[8];
            String Supply_Time = params[9];
            String Supplier_Name = params[10];
            String Supplier_Address = params[11];
            String Abuse_Time = params[12];
            String Place_Of_Purchase = params[13];
            String Suggestions = params[14];
            String ID = params[15];


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(deaddiction_identification_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Number_of_Narcotics_Users", Users));
                nameValuePairs.add(new BasicNameValuePair("Names_Of_Users", User_Name));
                nameValuePairs.add(new BasicNameValuePair("Addresses_of_Users", User_Address));
                nameValuePairs.add(new BasicNameValuePair("Type_of_Drugs_Used", Narcotics_Type));
                nameValuePairs.add(new BasicNameValuePair("Price_of_Drugs", Narcotics_Price));
                nameValuePairs.add(new BasicNameValuePair("Reason_for_Drug_Abuse", Drug_Abuse_Reason));
                nameValuePairs.add(new BasicNameValuePair("Drug_Abuse_Prone_Area", Drug_Abuse_Hotspot));
                nameValuePairs.add(new BasicNameValuePair("Gathering_Area_for_Abuser", Drug_Abusers_Gathering_Areas));
                nameValuePairs.add(new BasicNameValuePair("Time_of_Supply", Supply_Time));
                nameValuePairs.add(new BasicNameValuePair("Name_of_Supplier", Supplier_Name));
                nameValuePairs.add(new BasicNameValuePair("Address_of_Supplier", Supplier_Address));
                nameValuePairs.add(new BasicNameValuePair("Time_of_Consumption", Abuse_Time));
                nameValuePairs.add(new BasicNameValuePair("Place_of_Purchase", Place_Of_Purchase));
                nameValuePairs.add(new BasicNameValuePair("Suggestions", Suggestions));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;

        }

        else if(type.equals("deaddiction motivation"))
        {
            String Victims_Approached = params[1];
            String Approach_Method = params[2];
            String Victim_Approach_Problems =params[3];;
            String Family_Friends_Approach_Problems =  params[4];
            String Arguments = params[5];
            String Convincing_Factor = params[6];
            String Victim_Attitude = params[7];
            String Revisit_Needed = params[8];
            String Suggestions = params[9];
            String ID = params[10];


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(deaddiction_motivation_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Number_of_Victims_Approached_Monthly", Victims_Approached));
                nameValuePairs.add(new BasicNameValuePair("Method_of_Approach", Approach_Method));
                nameValuePairs.add(new BasicNameValuePair("Problems_Regarding_Victims", Victim_Approach_Problems));
                nameValuePairs.add(new BasicNameValuePair("Problems_Regarding_Victims_Families", Family_Friends_Approach_Problems));
                nameValuePairs.add(new BasicNameValuePair("Arguments_given_by_them", Arguments));
                nameValuePairs.add(new BasicNameValuePair("Convincing_Factor_Given", Convincing_Factor));
                nameValuePairs.add(new BasicNameValuePair("Attitude_of_Victims", Victim_Attitude));
                nameValuePairs.add(new BasicNameValuePair("Victims_Needing_Revisit", Revisit_Needed));
                nameValuePairs.add(new BasicNameValuePair("Suggestions", Suggestions));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;

        }

        else if(type.equals("deaddiction facilitation"))
        {

            String Linked_To_Centres = params[1];
            String Centre_Contacted =  params[2];
            String Centre_Issues = params[3];
            String Drop_Outs = params[4];
            String Dropout_Reason = params[5];
            String Successfully_Being_Treated =  params[6];
            String Problems = params[7];
            String Suggestions = params[8];
            String ID = params[9];

            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(deaddiction_facilitation_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Number_of_Approached_Victims_Linked_to_an_OOAT_Centre", Linked_To_Centres));
                nameValuePairs.add(new BasicNameValuePair("Centre_Contacted", Centre_Contacted));
                nameValuePairs.add(new BasicNameValuePair("Issues_with_Centre_Linking", Centre_Issues));
                nameValuePairs.add(new BasicNameValuePair("Treatment_Drop_Outs", Drop_Outs));
                nameValuePairs.add(new BasicNameValuePair("Reasons_For_Drop_Out", Dropout_Reason));
                nameValuePairs.add(new BasicNameValuePair("Victims_Continuing_Treatment", Successfully_Being_Treated));
                nameValuePairs.add(new BasicNameValuePair("Other_Problems", Problems));
                nameValuePairs.add(new BasicNameValuePair("Suggestions", Suggestions));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;

        }

        else if(type.equals("vg identification"))
        {
            String Vulnerables_Identified = params[1];
            String Vulnerables_Counseled = params[2];
            String Problems = params[3];
            String Suggestions =  params[4];
            String ID = params[5];


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(vg_identification_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Number_of_Vulnerable_Individuals_or_Groups_Identified", Vulnerables_Identified));
                nameValuePairs.add(new BasicNameValuePair("Number_of_Vulnerable_Individuals_or_Groups_Counseled", Vulnerables_Counseled));
                nameValuePairs.add(new BasicNameValuePair("Problems", Problems));
                nameValuePairs.add(new BasicNameValuePair("Suggestions", Suggestions));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;


        }

        else if(type.equals("vg protection"))
        {
            String Efforts_For_Protection = params[1];
            String People_Counseled = params[2];
            String Expert_Counselling_Advised =  params[3];
            String Counselling_Problems = params[4];
            String VG_Acceptance_Problems = params[5];
            String Other_VG_Problems = params[6];
            String Suggestions =  params[7];
            String ID = params[8];


            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(vg_protection_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Efforts_Made_for_Protection_of_Vulnerable_Groups", Efforts_For_Protection));
                nameValuePairs.add(new BasicNameValuePair("Vulnerable_Individuals_Counseled", People_Counseled));
                nameValuePairs.add(new BasicNameValuePair("Individuals_Recommended_for_Specific_Expert_Counselling", Expert_Counselling_Advised));
                nameValuePairs.add(new BasicNameValuePair("Problems_Regarding_Counselling_Arrangement", Counselling_Problems));
                nameValuePairs.add(new BasicNameValuePair("Problems_Regarding_Acceptance_of_a_Need_of_Protection", VG_Acceptance_Problems));
                nameValuePairs.add(new BasicNameValuePair("Other_Problems", Other_VG_Problems));
                nameValuePairs.add(new BasicNameValuePair("Suggestions", Suggestions));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));

                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;

         }

        else if(type.equals("awareness"))
        {
            String Awareness_Activity_Completion = params[1];
            String Activity_Performed_for_Awareness = params[2];
            String Activity_Audience = params[3];
            String Audience_Feedback = params[4];
            String Problems = params[5];
            String Suggestions = params[6];
            String ID = params[7];
            String fname1 = params[8];



            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(awareness_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Awareness_Activity_Completion", Awareness_Activity_Completion));
                nameValuePairs.add(new BasicNameValuePair("Activity_Performed_for_Awareness", Activity_Performed_for_Awareness));
                nameValuePairs.add(new BasicNameValuePair("Activity_Audience", Activity_Audience));
                nameValuePairs.add(new BasicNameValuePair("Audience_Feedback", Audience_Feedback));
                nameValuePairs.add(new BasicNameValuePair("Problems_Faced", Problems));
                nameValuePairs.add(new BasicNameValuePair("Suggestions", Suggestions));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));
                nameValuePairs.add(new BasicNameValuePair("filename", fname1));


                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;


        }

        else if(type.equals("positive activity"))
        {
            String Positive_Activity_Status = params[1];
            String Positive_Activity = params[2];
            String Activity_Venue = params[3];
            String Activity_Time = params[4];
            String Activity_Duration = params[5];
            String Potential_Participants_Number = params[6];
            String Actual_Participants_Number = params[7];
            String Participants = params[8];
            String Official_Availability = params[9];
            String Official_Identity = params[10];
            String Problem_Status = params[11];
            String Problems = params[12];
            String Existing_Infrastructure = params[13];
            String Infrastructure_Changes = params[14];
            String Infrastructure_Problems = params[15];
            String Suggestions = params[16];
            String ID = params[17];
            String fname1 = params[18];

            HttpClient httpclient = new DefaultHttpClient();
            HttpPost httppost = new HttpPost(positive_activity_url);
            HttpConnectionParams.setConnectionTimeout(httpclient.getParams(), 25000);
            HttpConnectionParams.setSoTimeout(httpclient.getParams(), 25000);

            try {
                List<NameValuePair> nameValuePairs = new ArrayList<>(15);

                nameValuePairs.add(new BasicNameValuePair("Positive_Activity_Completion", Positive_Activity_Status));
                nameValuePairs.add(new BasicNameValuePair("Positive_Activity_Performed", Positive_Activity));
                nameValuePairs.add(new BasicNameValuePair("Activity_Venue", Activity_Venue));
                nameValuePairs.add(new BasicNameValuePair("Time_at_Which_Activity_Was_Performed", Activity_Time));
                nameValuePairs.add(new BasicNameValuePair("Activity_Duration", Activity_Duration));
                nameValuePairs.add(new BasicNameValuePair("Number_of_People_Invited_to_Participate", Potential_Participants_Number));
                nameValuePairs.add(new BasicNameValuePair("Actual_Number_of_Participants", Actual_Participants_Number));
                nameValuePairs.add(new BasicNameValuePair("Participants", Participants));
                nameValuePairs.add(new BasicNameValuePair("Availability_of_an_Official", Official_Availability));
                nameValuePairs.add(new BasicNameValuePair("Identity_of_the_Official", Official_Identity));
                nameValuePairs.add(new BasicNameValuePair("Existence_of_Problem", Problem_Status));
                nameValuePairs.add(new BasicNameValuePair("Problem", Problems));
                nameValuePairs.add(new BasicNameValuePair("Existing_Infrastructure", Existing_Infrastructure));
                nameValuePairs.add(new BasicNameValuePair("Changes_Made_in_Infrastructure", Infrastructure_Changes));
                nameValuePairs.add(new BasicNameValuePair("Problems_Faced_Regarding_Infrastructure", Infrastructure_Problems));
                nameValuePairs.add(new BasicNameValuePair("Suggestions", Suggestions));
                nameValuePairs.add(new BasicNameValuePair("UID", ID));
                nameValuePairs.add(new BasicNameValuePair("filename", fname1));


                httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                HttpResponse response = httpclient.execute(httppost);
                String responseBody = EntityUtils.toString(response.getEntity());
                result = responseBody.trim();
                Utilities.LogDebug(result);
            } catch (ClientProtocolException e) {
                Utilities.LogDebug("error " + e.getMessage());
            } catch (IOException e) {
                Utilities.LogDebug("error " + e.getMessage());
            }
            return result;

        }


        return null;


    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);

    }

    @Override
    protected void onPostExecute(String result) {
        if (progDialog != null) {

            progDialog.dismiss();
            if (result.equals("Login Successful")) {

                AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);

                alertDialog.setCancelable(false);

                alertDialog.setMessage("Please enter the OTP sent to your registered Mobile Number!");

                alertDialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        context.startActivity(new Intent(context, otp_page.class));
                        ((Activity) context).finish();

                    }
                });
                AlertDialog dialog = alertDialog.create();
                dialog.show();


            }

            else if (result.equals("Submission Successful")) {

                context.startActivity(new Intent(context, Submit_screen.class));

                ((Activity) context).finish();
            }

            else {

                AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);

                alertDialog.setCancelable(false);

                alertDialog.setMessage(result);

                alertDialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                       // clue.requestFocus();
                    }
                });
                AlertDialog dialog = alertDialog.create();
                dialog.show();
            }
        }
    }


}