package com.example.jagma.login_screen;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Motivation_feedback extends AppCompatActivity {

    EditText d_m_a1, d_m_a6,  d_m_a8, d_m_a9;
    Spinner d_m_a2,d_m_a3,d_m_a4,d_m_a5,d_m_a7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motivation_feedback);



        d_m_a1 = findViewById(R.id.d_m_a1);
        d_m_a2 = findViewById(R.id.d_m_a2);
        d_m_a3 = findViewById(R.id.d_m_a3);
        d_m_a4 = findViewById(R.id.d_m_a4);
        d_m_a5 = findViewById(R.id.d_m_a5);
        d_m_a6 = findViewById(R.id.d_m_a6);
        d_m_a7 = findViewById(R.id.d_m_a7);
        d_m_a8 = findViewById(R.id.d_m_a8);
        d_m_a9 = findViewById(R.id.d_m_a9);
    }

    public void Proceed(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to submit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        /*Intent i=new  Intent(Motivation_feedback.this,Submit_screen.class);
                        startActivityForResult(i,2);
                        finish();*/

                        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                        if(connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED)
                        {

                            String Victims_Approached = d_m_a1.getText().toString();
                            String Approach_Method = d_m_a2.getSelectedItem().toString();;
                            String Victim_Approach_Problems = d_m_a3.getSelectedItem().toString();
                            String Family_Approach_Problems =  d_m_a4.getSelectedItem().toString();
                            String Arguments = d_m_a5.getSelectedItem().toString();
                            String Convincing_Factor = d_m_a6.getText().toString();
                            String Victim_Attitude = d_m_a7.getSelectedItem().toString();
                            String Revisit_Needed = d_m_a8.getText().toString();
                            String Suggestions =  d_m_a9.getText().toString();

                            String type="deaddiction motivation";
                            BackgroundWorker backgroundWorker = new BackgroundWorker(Motivation_feedback.this);

                            SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(Motivation_feedback.this);
                            String ID =sharedPreferences.getString("ID","unknown");

                            backgroundWorker.execute(type, Victims_Approached, Approach_Method, Victim_Approach_Problems, Family_Approach_Problems,
                                    Arguments, Convincing_Factor, Victim_Attitude, Revisit_Needed, Suggestions, ID );


                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),"No Internet Connection",Toast.LENGTH_LONG).show();
                            return;
                        }



                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();

    }
}
