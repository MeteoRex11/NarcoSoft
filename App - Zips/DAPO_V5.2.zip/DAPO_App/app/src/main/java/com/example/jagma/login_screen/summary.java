package com.example.jagma.login_screen;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;

public class summary extends AppCompatActivity {

    Context context;
    Spinner date_dd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        date_dd=findViewById(R.id.date_dd);
        context=this;

        String motivation;

        date_dd.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // your code here

                String month=date_dd.getSelectedItem().toString();
                SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(summary.this);
                String ID =sharedPreferences.getString("ID","unknown");
                BackgroundWorker backgroundWorker = new BackgroundWorker(context);
                String type="summary";

                backgroundWorker.execute(type,month, ID);

        }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // your code here
            }

        });


    }
}
