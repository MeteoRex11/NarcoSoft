package com.example.jagma.login_screen;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

import io.apptik.widget.multiselectspinner.MultiSelectSpinner;

public class Follow_Up_Feedback extends AppCompatActivity {

    EditText fu_a1;
    MultiSelectSpinner fu_a2,fu_a3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_follow__up__feedback);

        fu_a1=findViewById(R.id.d_fu_a1);
        fu_a2=findViewById(R.id.d_fu_a2);
        fu_a3=findViewById(R.id.d_fu_a3); // Declaration


        ArrayList<String> options1 = new ArrayList<>();
        options1.add(getString(R.string.fu_a2_r1));
        options1.add(getString(R.string.fu_a2_r2));
        options1.add(getString(R.string.fu_a2_r3));
        options1.add(getString(R.string.fu_a2_r4));
        options1.add(getString(R.string.fu_a2_r5));
        //options1.add(getString(R.string.any));
        ArrayAdapter<String> adapter1 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options1);

        fu_a2.setListAdapter(adapter1)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText(getString(R.string.selAll))
                .setAllUncheckedText(getString(R.string.fu_a2_prompt))
                .setSelectAll(false)
                .setTitle(getString(R.string.fu_a2_prompt))
                .setMinSelectedItems(1); // Spinner 1


        ArrayList<String> options2 = new ArrayList<>();
        options2.add(getString(R.string.d_f_a3_prb1));
        options2.add(getString(R.string.d_f_a3_prb2));
        options2.add(getString(R.string.d_f_a3_prb3));
        options2.add(getString(R.string.d_f_a3_prb4));
        //options2.add(getString(R.string.any));
        ArrayAdapter<String> adapter2= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options2);

        fu_a3.setListAdapter(adapter2)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText(getString(R.string.selAll))
                .setAllUncheckedText(getString(R.string.d_f_a3_prompt))
                .setSelectAll(false)
                .setTitle(getString(R.string.d_f_a3_prompt))
                .setMinSelectedItems(1); // Spinner 2
    }

    public void Proceed(View view){

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getString(R.string.dialog_proceed_head))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        /*Intent i=new  Intent(Facilitation_Feedback.this,Submit_screen.class);
                        startActivityForResult(i,2);
                        finish();*/

                        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                        if(connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED)
                        {


                            String Drop_Outs = fu_a1.getText().toString();
                            String Dropout_Reason = fu_a2.getSelectedItem().toString();
                            String Problems =  fu_a3.getSelectedItem().toString();

                            String type="deaddiction followup";
                            BackgroundWorker backgroundWorker = new BackgroundWorker(Follow_Up_Feedback.this);

                            SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(Follow_Up_Feedback.this);
                            String ID =sharedPreferences.getString("ID","unknown");

                            backgroundWorker.execute(type, Drop_Outs, Dropout_Reason, Problems, ID);


                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),getString(R.string.noNetConn),Toast.LENGTH_LONG).show();
                            return;
                        }

                    }
                })
                .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}