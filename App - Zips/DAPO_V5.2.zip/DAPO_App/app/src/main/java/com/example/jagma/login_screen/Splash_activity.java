package com.example.jagma.login_screen;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class Splash_activity extends langSelect {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_activity);

        SharedPreferences pref= getSharedPreferences("ActivityPref", Context.MODE_PRIVATE);
        SharedPreferences lang_pref= getSharedPreferences("langSel",Context.MODE_PRIVATE);

        setAppLocale(lang_pref.getString("selected_language","en"));

        Log.d("ADebugTag", "Value(Splash): " + lang_pref.getString("selected_language","en"));

        if (pref.getBoolean("activity_executed", false)) {
            Intent i =new Intent(this,Main_task_page.class);
            startActivity(i);
            finish();
        }
        else {
            Intent i =new Intent(this,langSelect.class);
            startActivity(i);
            finish();
        }
    }
}
