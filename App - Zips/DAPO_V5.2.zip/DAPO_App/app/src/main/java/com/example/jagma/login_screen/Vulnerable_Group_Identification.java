package com.example.jagma.login_screen;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Vulnerable_Group_Identification extends AppCompatActivity {

    EditText p_i_a1, p_i_a2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vulnerable__group__identification);

        p_i_a1 = findViewById(R.id.p_i_a1);
        p_i_a2 = findViewById(R.id.p_i_a2);

    }

    public void Proceed(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getString(R.string.dialog_proceed_head))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        /*Intent i=new  Intent(Vulnerable_Group_Identification.this,Submit_screen.class);
                        startActivityForResult(i,2);
                        finish();*/

                            ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
                            if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                    connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {

                                String Vulnerables_Identified = p_i_a1.getText().toString();
                                String Vulnerables_Counseled = p_i_a2.getText().toString();



                                String type="vg identification";
                                BackgroundWorker backgroundWorker = new BackgroundWorker(Vulnerable_Group_Identification.this);

                                SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(Vulnerable_Group_Identification.this);
                                String ID =sharedPreferences.getString("ID","unknown");

                                backgroundWorker.execute(type, Vulnerables_Identified, Vulnerables_Counseled, ID );


                            } else {
                                Toast.makeText(getApplicationContext(), getString(R.string.noNetConn), Toast.LENGTH_LONG).show();
                                return;
                            }





                    }
                })
                .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();

    }
}
