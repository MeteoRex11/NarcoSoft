package com.example.jagma.login_screen;


import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;

import java.util.ArrayList;

public class mohalla_status extends AppCompatActivity {

    //private static String TAG ="MainActivity";

    //HARD CODED VALUES TO BE CHANGED AS PER DATABASE

    public int      total_people = 1545,
                    healthy = 1050,
                    rehab = 250,
                    active_users = 75,
                    vulnerable = 70,
                    unknown = 100;

    TextView        total_ans;
    TextView        healthy_ans;
    TextView        treatment_ans;
    TextView        vul_ans;
    TextView        users_ans;
    TextView        unknown_ans;
    TextView        location_subhead;

    String location = "<Location>";



    //PERCENTAGE CALCULATION FOR DISPLAY

    public float hea_mod = ((float)healthy*100)/(float)total_people;
    public float rehab_mod = ((float)rehab*100)/(float)total_people;
    public float vul_mod = ((float)vulnerable*100)/(float)total_people;
    public float active_mod = ((float)active_users*100)/(float)total_people;
    public float unknown_mod = ((float)unknown*100)/(float)total_people;

    private float[] ydata ={hea_mod,rehab_mod,vul_mod,active_mod,unknown_mod};

    /*
    private String[] xdata={
            getString(R.string.xdata_1),
            getString(R.string.xdata_2),
            getString(R.string.xdata_3),
            getString(R.string.xdata_4),
            getString(R.string.xdata_5)
    };
    */

    private String[] xdata={
            "Healthy",
            "Rehabilitating",
            "Vulnerable",
            "Drug Abusing",
            "Unknown"
    };

    //GLOBAL pieChart
    PieChart pieChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mohalla_status);

        pieChart = (PieChart) findViewById(R.id.pie);

        //------------------------------------------------------------------------------------------
        //SETTING VALUES FOR FIELDS

     /* total_ans = findViewById(R.id.total_ans);
        healthy_ans = findViewById(R.id.healthy_ans);
        treatment_ans = findViewById(R.id.treatment_ans);
        vul_ans = findViewById(R.id.vul_ans);
        users_ans = findViewById(R.id.users_ans);
        unknown_ans = findViewById(R.id.unknown_ans);
        location_subhead = findViewById(R.id.location_subhead);

        total_ans.setText(getString(total_people));
        healthy_ans.setText(getString(healthy));
        treatment_ans.setText(getString(rehab));
        users_ans.setText(getString(active_users));
        vul_ans.setText(getString(vulnerable));
        unknown_ans.setText(getString(unknown));

        location_subhead.setText(location);*/

        //------------------------------------------------------------------------------------------


        //DESCRIPTION
        Description descrip = new Description();
        descrip.setText("");
        descrip.setTextSize(15f);
        pieChart.setDescription(descrip);
        pieChart.getDescription().setEnabled(false);


        //------------------------------------------------------------------------------------------

        //PIECHART PROPERTIES

        pieChart.setRotationEnabled(true);
        pieChart.setHoleRadius(50f);
        pieChart.setTransparentCircleAlpha(0);
        pieChart.setCenterText(getString(R.string.pie_center_msg));
        pieChart.setCenterTextSize(25f);
        pieChart.spin( 1400,-360f,0f, Easing.EasingOption.EaseInOutQuad);
        //pieChart.animate();
        addDataSet();
    }

    private void addDataSet() {
        ArrayList<PieEntry> yEntrys = new ArrayList<>();
        ArrayList<String> xEntrys = new ArrayList<>();

        for(int i=0;i<ydata.length;i++){
            yEntrys.add(new PieEntry(ydata[i],i));
        }

        for(int i=0;i<xdata.length;i++){
            xEntrys.add(xdata[i]);
        }

        PieDataSet set1 = new PieDataSet(yEntrys,getString(R.string.pie_bottom_label));
        set1.setSliceSpace(2);
        set1.setValueTextSize(10);

        ArrayList<Integer> colors = new ArrayList<>();
        //green-healthy
        colors.add(Color.rgb(177,242,0));
        //yellow-rehab
        colors.add(Color.rgb(255,222,32));
        //orange-vul
        colors.add(Color.rgb(255,157,0));
        //red-drugUsers
        colors.add(Color.rgb(255,165,165));
        //grey-unknown
        colors.add(Color.rgb(211,211,211));

        set1.setColors(colors);

        /*
        //LEGEND
        Legend legend = pieChart.getLegend();
        legend.setEnabled(false);
        legend.setForm(Legend.LegendForm.CIRCLE);
        legend.getEntries();
        */

        //object
        PieData pieData = new PieData(set1);
        pieChart.setData(pieData);
        pieData.setValueTextSize(18f);

        //pieData.setValueTextColor(Color.WHITE);

        //pieChart.animate(1400,1400);

        pieChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                //DEBUG
                //Log.d(TAG,"OnValueSelected: value selected ");
                //Log.d(TAG,"OnValueSelcted: "+ e.toString());
                //Log.d(TAG,"OnValueSelcted: "+ h.toString());
                //Log.d(TAG,"OnValueSelcted: ");

                // FOR SELECTED DISPLAY
                //int pos1=(int)(e.getY()*total_people)/100;
                //int stat=(int)h.getX();
                //Toast.makeText(mohalla_status.this, getString(R.string.pie_msg_start) + pos1 +" "+ xdata[stat] + getString(R.string.pie_msg_end) ,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected() {
            }
        });
    }
}
