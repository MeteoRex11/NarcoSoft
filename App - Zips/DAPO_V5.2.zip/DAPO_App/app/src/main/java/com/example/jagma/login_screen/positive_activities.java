package com.example.jagma.login_screen;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import io.apptik.widget.multiselectspinner.MultiSelectSpinner;


public class positive_activities extends AppCompatActivity {

    MultiSelectSpinner pa_a1, pa_a3, pa_a4;

    public static final int GET_FROM_GALLERY = 5;
    ImageView imageView;
    Uri selectedImage;


    public static String fpath1="",fname1="";

    public String uploadFilePath = "";
    public String uploadFileName = "";
    int serverResponseCode = 0;
    ProgressDialog dialog = null;
    String upLoadServerUri = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.positive_activities);

        pa_a3 =  findViewById(R.id.pa_a3);
        pa_a4 =  findViewById(R.id.pa_a4);

        pa_a1 =  findViewById(R.id.pa_a1);

        imageView = findViewById(R.id.imageviewP);


        ArrayList<String> activities = new ArrayList<>();
        activities.add(getString(R.string.pa_a2_act1));
        activities.add(getString(R.string.pa_a2_act2));
        activities.add(getString(R.string.pa_a2_act3));
        activities.add(getString(R.string.pa_a2_act4));
        //activities.add(getString(R.string.any));
        ArrayAdapter<String> adapterActivities = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, activities);

        pa_a1.setListAdapter(adapterActivities)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText(getString(R.string.selAll))
                .setAllUncheckedText(getString(R.string.pa_a2_prompt))
                .setSelectAll(false)
                .setTitle(getString(R.string.pa_a2_prompt))
                .setMinSelectedItems(1); // Spinner 1



        ArrayList<String> venue = new ArrayList<>();
        venue.add(getString(R.string.pa_a3_loc1));
        venue.add(getString(R.string.pa_a3_loc2));
        venue.add(getString(R.string.pa_a3_loc3));
        venue.add(getString(R.string.pa_a3_loc4));
        venue.add(getString(R.string.pa_a3_loc5));
        //venue.add(getString(R.string.any));
        ArrayAdapter<String> adapterVenues = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, venue);

        pa_a3.setListAdapter(adapterVenues)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText(getString(R.string.selAll))
                .setAllUncheckedText(getString(R.string.pa_a3_prompt))
                .setSelectAll(false)
                .setTitle(getString(R.string.pa_a3_prompt))
                .setMinSelectedItems(1); // Spinner 2


        ArrayList<String> problems = new ArrayList<>();
        problems.add(getString(R.string.pa_a5_prb1));
        problems.add(getString(R.string.pa_a5_prb2));
        problems.add(getString(R.string.pa_a5_prb3));
        problems.add(getString(R.string.pa_a5_prb4));
        //problems.add(getString(R.string.any));

        ArrayAdapter<String> adapterProblems = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, problems);

        pa_a4.setListAdapter(adapterProblems)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText(getString(R.string.selAll))
                .setAllUncheckedText(getString(R.string.pa_a5_prompt))
                .setSelectAll(false)
                .setTitle(getString(R.string.pa_a5_prompt))
                .setMinSelectedItems(1); // Spinner 2
    }

    public void Proceed(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(getString(R.string.dialog_proceed_head))
                .setCancelable(false)
                .setPositiveButton(getString(R.string.yes), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        /*Intent i=new  Intent(positive_activities.this,Submit_screen.class);
                        startActivityForResult(i,3);
                        finish();*/

                        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                        if(connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED)
                        {

                        }
                        else
                        {
                            Toast.makeText(getApplicationContext(),getString(R.string.noNetConn),Toast.LENGTH_LONG).show();
                            return;
                        }


                        String Positive_Activity = pa_a1.getSelectedItem().toString();
                        String Activity_Venue = pa_a3.getSelectedItem().toString();
                        String Problems = pa_a4.getSelectedItem().toString();


                        String type="positive activity";
                        BackgroundWorker backgroundWorker = new BackgroundWorker(positive_activities.this);

                        SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(positive_activities.this);
                        String ID = sharedPreferences.getString("ID","unknown");

                        backgroundWorker.execute(type,Positive_Activity, Activity_Venue, Problems, ID, fname1 );
                    }
                })
                .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==GET_FROM_GALLERY && resultCode == Activity.RESULT_OK) {
           /* selectedImage = data.getData();
            try{
                Bitmap bitmap= MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                imageView.setImageBitmap(bitmap);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }*/


            selectedImage = data.getData();

            try {
                Bitmap bitmap = null;
                BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
                bitmapOptions.inSampleSize = 2;
                try {
                    bitmap= MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                    imageView.setImageBitmap(bitmap);
                } catch (MalformedURLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }

                fpath1 = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/pvrimages/";
                File newdir = new File(fpath1);
                newdir.mkdirs();

                OutputStream outFile = null;
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyymmddhhmmss");
                String date = dateFormat.format(new Date());
                fname1="img_"+date+".jpg";
                File file = new File(fpath1+File.separator + fname1);
                try {
                    outFile = new FileOutputStream(file);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 60, outFile);
                    outFile.flush();
                    outFile.close();
                    imageView.setImageBitmap(bitmap);
                    imageView.setRotation(90);
                    imageView.setAdjustViewBounds(true);

                    imageView.getLayoutParams().height = 100;
                    imageView.getLayoutParams().width = 100;

                } catch (FileNotFoundException e) {
                    //e.printStackTrace();
                } catch (IOException e) {
                    //e.printStackTrace();
                } catch (Exception e) {
                    //	e.printStackTrace();
                }


            } catch (Exception e) {
                //e.printStackTrace();
            }


            uploadFilePath = fpath1;
            uploadFileName = fname1;


            new positive_activities.AsyncSender().execute();

        }
    }



    private final class AsyncSender extends AsyncTask<Void, Void, Void> {

        ProgressDialog pd;
        Integer rr=0;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pd = new ProgressDialog(positive_activities.this);
            pd.setTitle(getString(R.string.title_sav));
            pd.setMessage(getString(R.string.body_sav));
            pd.setCancelable(false);
            pd.setIndeterminate(true);
            pd.show();
        }

        @Override
        protected Void doInBackground(Void... params) {
            try{
                rr=uploadFile(uploadFilePath + "" + uploadFileName); // You probably have to try/catch this
                System.out.println(rr);
            }
            catch (Exception e) {
                //e.printStackTrace();
                //  System.out.println("error"+resp);
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);

            pd.dismiss();

        }
    }



    public int uploadFile(String sourceFileUri) {


        String fileName = sourceFileUri;

        HttpURLConnection conn = null;
        DataOutputStream dos = null;
        String lineEnd = "\r\n";
        String twoHyphens = "--";
        String boundary = "*****";
        int bytesRead, bytesAvailable, bufferSize;
        byte[] buffer;
        int maxBufferSize = 1 * 1024 * 1024;

        File sourceFile = new File(sourceFileUri);


        if(sourceFile.isFile()){

            try {

                // open a URL connection to the Servlet
                FileInputStream fileInputStream = new FileInputStream(sourceFile);
                upLoadServerUri = "http://115.112.58.50:8097/dapoapi/positive/UploadToServer_data_snap.php";

                URL url = new URL(upLoadServerUri);


                // Open a HTTP  connection to  the URL
                conn = (HttpURLConnection) url.openConnection();
                conn.setDoInput(true); // Allow Inputs
                conn.setDoOutput(true); // Allow Outputs
                conn.setUseCaches(false); // Don't use a Cached Copy
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Connection", "Keep-Alive");
                conn.setRequestProperty("ENCTYPE", "multipart/form-data");
                conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
                conn.setRequestProperty("uploaded_file", fileName);

                dos = new DataOutputStream(conn.getOutputStream());

                dos.writeBytes(twoHyphens + boundary + lineEnd);
                dos.writeBytes("Content-Disposition: form-data; name=\"uploaded_file\";filename=\""
                        + fileName + "\"" + lineEnd);

                dos.writeBytes(lineEnd);

                // create a buffer of  maximum size
                bytesAvailable = fileInputStream.available();

                bufferSize = Math.min(bytesAvailable, maxBufferSize);
                buffer = new byte[bufferSize];

                // read file and write it into form...
                bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                while (bytesRead > 0) {

                    dos.write(buffer, 0, bufferSize);
                    bytesAvailable = fileInputStream.available();
                    bufferSize = Math.min(bytesAvailable, maxBufferSize);
                    bytesRead = fileInputStream.read(buffer, 0, bufferSize);

                }

                // send multipart form data necesssary after file data...
                dos.writeBytes(lineEnd);
                dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);

                // Responses from the server (code and message)
                serverResponseCode = conn.getResponseCode();
                String serverResponseMessage = conn.getResponseMessage();

                Log.i("uploadFile", "HTTP Response is : "
                        + serverResponseMessage + ": " + serverResponseCode);

                if(serverResponseCode == 200){

                    runOnUiThread(new Runnable() {
                        public void run() {

                            //messageText.setText(msg);
                            Toast.makeText(positive_activities.this, "File Upload Complete1.",
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                }

                //close the streams //
                fileInputStream.close();
                dos.flush();
                dos.close();

            } catch (MalformedURLException ex) {


                //  ex.printStackTrace();

                runOnUiThread(new Runnable() {
                    public void run() {
                        //  messageText.setText("MalformedURLException Exception : check script url.");
                        //  Toast.makeText(MainActivity.this, "MalformedURLException", Toast.LENGTH_SHORT).show();
                    }
                });

                Log.e("Upload file to server", "error: " + ex.getMessage(), ex);
            } catch (Exception e) {

                // e.printStackTrace();

                runOnUiThread(new Runnable() {
                    public void run() {
                        //messageText.setText("Got Exception : see logcat ");
                        //Toast.makeText(MainActivity.this, "Got Exception : see logcat ",
                        //		  Toast.LENGTH_SHORT).show();
                    }
                });
                //   Log.e("Upload file to server Exception", "Exception : "+ e.getMessage(), e);
            }
        }
        return 2;
        // End else block
    }

    public void openGallery(View view){
        startActivityForResult(new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI), GET_FROM_GALLERY);
    }
}
