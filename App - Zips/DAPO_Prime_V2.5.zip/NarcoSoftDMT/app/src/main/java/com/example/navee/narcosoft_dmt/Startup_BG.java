package com.example.navee.narcosoft_dmt;


import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.AsyncTask;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import android.content.Intent;
import android.widget.Toast;


public class Startup_BG extends AsyncTask<String,Void,String> {

    Context context;
    AlertDialog alertDialog;
    Startup_BG (Context ctx){
        context = ctx;
    }


    @Override
    protected void onPreExecute() {
        alertDialog = new AlertDialog.Builder(context).create();
        alertDialog.setTitle("");


    }


    @Override
    protected String doInBackground(String... params) {

        String ROLE = params[0];
        String login_url = "http://192.168.1.8/login_screen/login.php";
        String dmt_url = "http://192.168.1.8/login_screen/dmt.php";
        String sdmt_url = "http://192.168.1.8/login_screen/sdmt.php";
        String cc_url = "http://192.168.1.8/login_screen/cc.php";
        String nrnc_url = "http://192.168.1.8/login_screen/nrnc.php";


        if (ROLE.equals("login"))
        {
            String UID = params[1];
            String mobno = params[2];
            try {

                URL url = new URL(login_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));

                String data_string = URLEncoder.encode("UID", "UTF-8") + "=" + URLEncoder.encode(UID, "UTF-8") + "&" +
                        URLEncoder.encode("Mobile_Number", "UTF-8") + "=" + URLEncoder.encode(mobno, "UTF-8");

                bufferedWriter.write(data_string);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader =new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while((line=bufferedReader.readLine())!=null){
                    result +=line;
                }


                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();

                return result;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }



        else if(ROLE.equals("dmt"))
        {
            String type = params[1];

            if(type.equals("home")) {
                context.startActivity(new Intent(context, home_page.class));
                ((Activity) context).finish();
            }

            else if(type.equals("report")) {
                context.startActivity(new Intent(context, report_page.class));
                ((Activity) context).finish();
            }

            else if(type.equals("dcheck")) {
                context.startActivity(new Intent(context, data_check.class));
                ((Activity) context).finish();
            }

        }

        else if(ROLE.equals("sdmt"))
        {
            String type = params[1];

            if(type.equals("home")) {
                context.startActivity(new Intent(context, home_page.class));
                ((Activity) context).finish();
            }

            else if(type.equals("report")) {
                context.startActivity(new Intent(context, report_page_sdmt.class));
                ((Activity) context).finish();
            }

            else if(type.equals("dcheck")) {
                context.startActivity(new Intent(context, data_check_sdmt.class));
                ((Activity) context).finish();
            }


            else if(type.equals("list")) {
                context.startActivity(new Intent(context, list_sdmt.class));
                ((Activity) context).finish();
            }



        }

        else if(ROLE.equals("cc"))
        {

            String type = params[1];

            if(type.equals("home")) {
                context.startActivity(new Intent(context, home_page.class));
                ((Activity) context).finish();
            }

            else if(type.equals("report")) {
                context.startActivity(new Intent(context, report_page_cc.class));
                ((Activity) context).finish();
            }

            else if(type.equals("dcheck")) {
                context.startActivity(new Intent(context, data_check_cc.class));
                ((Activity) context).finish();
            }

            else if(type.equals("list")) {
                context.startActivity(new Intent(context, list_cc.class));
                ((Activity) context).finish();
            }

        }

        else if(ROLE.equals("nrnc"))
        {
            String type = params[1];

            if(type.equals("home")) {
                context.startActivity(new Intent(context, home_page.class));
                ((Activity) context).finish();
            }

            else if(type.equals("report")) {
                context.startActivity(new Intent(context, report_page_nrnc.class));
                ((Activity) context).finish();
            }

            else if(type.equals("dcheck")) {
                context.startActivity(new Intent(context, list_dapo.class));
                ((Activity) context).finish();
            }

            else if(type.equals("list")) {
                context.startActivity(new Intent(context, list_nrnc.class));
                ((Activity) context).finish();
            }


        }


        return null;


    }

    @Override
    protected void onPostExecute(String result)
    {
        alertDialog.setMessage(result);
        alertDialog.show();

        if (result.equals("Login Successful"))
        {

            context.startActivity(new Intent(context, home_page.class));
            ((Activity)context).finish();
        }

        /*else if(result.equals("Submission Successful"))
        {
            context.startActivity(new Intent(context, Submit_screen.class));
            ((Activity)context).finish();
        }*/
    }


}