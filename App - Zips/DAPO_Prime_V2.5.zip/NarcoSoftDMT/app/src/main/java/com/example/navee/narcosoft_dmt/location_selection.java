package com.example.navee.narcosoft_dmt;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class location_selection extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.location_selection);
    }

    public void Proceed(View view) {
        /*String type="dcheck";
        Startup_BG backgroundWorker = new Startup_BG(this);
        backgroundWorker.execute(type);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String Role_retrieved = sharedPreferences.getString("ROLE", "unknown");

        if (Role_retrieved.equals("DMT")) {*/
            Intent i = new Intent(location_selection.this, data_check.class);
            startActivity(i);
            finish();
       /* }

        else if (Role_retrieved.equals("SDMT")) {
            Intent i = new Intent(location_selection.this, data_check_sdmt.class);
            startActivity(i);
            finish();
        }

        else if (Role_retrieved.equals("NRNC")) {
            Intent i = new Intent(location_selection.this, list_dapo.class);
            startActivity(i);
            finish();
        }

        else if (Role_retrieved.equals("CC")) {
            Intent i = new Intent(location_selection.this, data_check_cc.class);
            startActivity(i);
            finish();
        }*/
    }

}