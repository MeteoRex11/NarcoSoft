package com.example.navee.narcosoft_dmt;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Toast;

public class list_dapo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_dapo);
    }

    public void info_dapo(View view)
    {
        Toast msg=Toast.makeText(list_dapo.this,"Opening...",Toast.LENGTH_SHORT);
        msg.show();

        Intent i = new Intent(this,info_dapo.class);
        startActivity(i);
    }
}
