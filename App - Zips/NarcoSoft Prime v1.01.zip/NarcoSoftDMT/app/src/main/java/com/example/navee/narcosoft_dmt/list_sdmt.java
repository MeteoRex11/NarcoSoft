package com.example.navee.narcosoft_dmt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class list_sdmt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_sdmt);
    }

    public void info_sdmt(View view)
    {
        Intent i=new Intent(list_sdmt.this,info_sdmt.class);
        startActivity(i);
    }
}
