package com.example.navee.narcosoft_dmt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class list_nrnc extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_nrnc);
    }

    public void info_nrnc(View view)
    {
        Intent i=new Intent(list_nrnc.this,info_nrnc.class);
        startActivity(i);
    }
}
