package com.example.navee.narcosoft_dmt;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.Toast;

public class Sign_Up extends AppCompatActivity {

    Spinner Role;
    public static final int GET_FROM_GALLERY = 6;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign__up);

        Role=findViewById(R.id.role_a1);

    }


    public void proceed(View view){


        String Role_Selected= Role.getSelectedItem().toString().toLowerCase();

        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("ROLE", Role_Selected);
        editor.apply();

        Intent intent= new Intent(this,home_page.class);
        startActivity(intent);
        finish();
    }


    public void openGallery(View view){

        startActivityForResult(new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI), GET_FROM_GALLERY);


    }

}
