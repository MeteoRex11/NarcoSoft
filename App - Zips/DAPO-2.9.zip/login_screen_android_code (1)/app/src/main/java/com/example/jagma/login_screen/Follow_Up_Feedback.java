package com.example.jagma.login_screen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;

import java.util.ArrayList;

import io.apptik.widget.multiselectspinner.MultiSelectSpinner;

public class Follow_Up_Feedback extends AppCompatActivity {

    MultiSelectSpinner fu_a1,fu_a2,fu_a3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_follow__up__feedback);

        fu_a1=findViewById(R.id.d_fu_a2);
        fu_a2=findViewById(R.id.d_fu_a5);
        fu_a3=findViewById(R.id.d_fu_a6);


        ArrayList<String> options2 = new ArrayList<>();
        options2.add("1");
        options2.add("2");
        options2.add("3");
        options2.add("A");
        options2.add("B");
        options2.add("C");
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options2);

        fu_a1.setListAdapter(adapter2)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All types")
                .setAllUncheckedText("none selected")
                .setSelectAll(false)
                .setTitle("Choose Reasons")
                .setMinSelectedItems(1);


        ArrayList<String> options3 = new ArrayList<>();
        options3.add("1");
        options3.add("2");
        options3.add("3");
        options3.add("A");
        options3.add("B");
        options3.add("C");
        ArrayAdapter<String> adapter3= new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options3);

        fu_a2.setListAdapter(adapter3)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All types")
                .setAllUncheckedText("none selected")
                .setSelectAll(false)
                .setTitle("Choose Problems")
                .setMinSelectedItems(1);


        ArrayList<String> options4 = new ArrayList<>();
        options4.add("1");
        options4.add("2");
        options4.add("3");
        options4.add("A");
        options4.add("B");
        options4.add("C");
        ArrayAdapter<String> adapter4 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_multiple_choice, options4);

        fu_a3.setListAdapter(adapter4)
                .setListener(new MultiSelectSpinner.MultiSpinnerListener() {
                    @Override
                    public void onItemsSelected(boolean[] selected) {

                    }
                })
                .setAllCheckedText("All types")
                .setAllUncheckedText("none selected")
                .setSelectAll(false)
                .setTitle("Choose Suggestions")
                .setMinSelectedItems(1);
    }
}
