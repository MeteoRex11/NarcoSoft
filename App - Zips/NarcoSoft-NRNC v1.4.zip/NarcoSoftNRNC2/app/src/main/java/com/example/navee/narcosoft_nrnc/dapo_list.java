package com.example.navee.narcosoft_nrnc;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class dapo_list extends AppCompatActivity {

    int[] Dps={R.drawable.account_ph};

    String[] dapo_names={"CJ","ryder","big smoke","snoop dogg","50 cent","tupac","lil wayne"
    ,"wiz khalifa","travie mmccoy","sallu bhai"};

    String role="DAPO";

    String[] location={"zirkapur","panchkula","chandigarh","location","location","location"
    ,"location","location","location","location"};


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dapo_list);

        SharedPreferences pref=getSharedPreferences("ActivityPref",MODE_PRIVATE);
        SharedPreferences.Editor edt =pref.edit();
        edt.putBoolean("activity_executed",true);
        edt.apply();

        ListView listView=findViewById(R.id.lv_1);

        CustomAdapter customAdapter =new CustomAdapter();
        listView.setAdapter(customAdapter);
    }

    public void message_toast(View view)
    {
        Toast msg=Toast.makeText(dapo_list.this,"Opening...",Toast.LENGTH_SHORT);
        msg.show();
        Intent i = new Intent(this,info_page.class);
        startActivity(i);
    }

    public void new_user(View view)
    {
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
        finish();
    }

    class CustomAdapter extends BaseAdapter{


        @Override
        public int getCount() {
            return dapo_names.length;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View convertView, ViewGroup parent) {
            convertView =getLayoutInflater().inflate(R.layout.dapo_list_listview_layout,null);

            TextView dapo_name=convertView.findViewById(R.id.user_1);
            TextView roles=convertView.findViewById(R.id.textView5);
            TextView dapo_location=convertView.findViewById(R.id.location_1);

            ImageView imageView=convertView.findViewById(R.id.dapo_uid_1);

            dapo_name.setText(dapo_names[i]);
            roles.setText(role);
            dapo_location.setText(location[i]);

            imageView.setImageResource(Dps[0]);


            return convertView;
        }
    }
}