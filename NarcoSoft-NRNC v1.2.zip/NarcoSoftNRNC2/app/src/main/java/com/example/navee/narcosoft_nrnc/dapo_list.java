package com.example.navee.narcosoft_nrnc;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class dapo_list extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dapo_list);

        SharedPreferences pref=getSharedPreferences("ActivityPref",MODE_PRIVATE);
        SharedPreferences.Editor edt =pref.edit();
        edt.putBoolean("activity_executed",true);
        edt.apply();
    }

    public void message_toast(View view)
    {
        Toast msg=Toast.makeText(dapo_list.this,"Opening...",Toast.LENGTH_SHORT);
        msg.show();
        Intent i = new Intent(this,info_page.class);
        startActivity(i);
    }

    public void new_user(View view)
    {
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
        finish();
    }
}