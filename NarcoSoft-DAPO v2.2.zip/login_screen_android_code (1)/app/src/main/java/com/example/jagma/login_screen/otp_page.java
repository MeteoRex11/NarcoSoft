package com.example.jagma.login_screen;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import java.util.Random;

public class otp_page extends AppCompatActivity {

    Context context;

    EditText otp;
    public int rand = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.otp_page);

        otp = findViewById(R.id.editText3);

        MainActivity mn = new MainActivity();

        //Random r = new Random( System.currentTimeMillis() );
        rand = mn.rand; //10000 + r.nextInt(20000);
    }

    public void Verify(View view) {

        if(otp.getText().toString().equals(String.valueOf(rand))) {

            AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);

            alertDialog.setCancelable(false);

            alertDialog.setMessage("Verified Successfully");

            alertDialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            AlertDialog dialog = alertDialog.create();
            dialog.show();


            this.startActivity(new Intent(this, Main_task_page.class));
            ((Activity) this).finish();

        }
        else{

            AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);

            alertDialog.setCancelable(false);

            alertDialog.setMessage("OTP Incorrect!!");

            alertDialog.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {

                }
            });
            AlertDialog dialog = alertDialog.create();
            dialog.show();

        }

    }

}
