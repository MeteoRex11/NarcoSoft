package com.example.jagma.login_screen;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.view.View;
import android.preference.PreferenceManager;
import android.content.SharedPreferences;

public class MainActivity extends Activity{

    EditText UIDet, MobNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        UIDet=findViewById(R.id.editText);
        MobNo=findViewById(R.id.editText2);


    }



    public void OnLogin(View view){

        String uid = UIDet.getText().toString();
        String mobno = MobNo.getText().toString();
        String type="login";
        BackgroundWorker backgroundWorker=new BackgroundWorker(this);
        backgroundWorker.execute(type,uid,mobno);

        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("ID", uid);
        editor.apply();

        Intent intent = new Intent(this,Main_task_page.class);
        startActivity(intent);
        finish();

    }
}
