package com.example.jagma.login_screen;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.preference.PreferenceManager;
import android.content.SharedPreferences;

import java.io.FileNotFoundException;
import java.io.IOException;


public class Awareness_Activity extends AppCompatActivity {

   EditText a_a3, a_a4, a_a5, a_a6,a_a7;
   String radioText, radioText2;
    RadioButton radioButton01,radioButton02;
    RadioGroup a_RB1, RGrp;
    public static final int GET_FROM_GALLERY = 4;
    ImageView imageView;
    Uri selectedImage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_awareness_);

        a_RB1 = findViewById(R.id.a_RB1);


        RGrp = findViewById(R.id.RGrp);


        a_a3 = findViewById(R.id.a_a3);
        a_a4 = findViewById(R.id.a_a4);
        a_a5 = findViewById(R.id.a_a5);
        a_a6 = findViewById(R.id.a_a6);
        a_a7 = findViewById(R.id.radioText);
        //a_a7.setVisibility(View.INVISIBLE);
        imageView = findViewById(R.id.imageviewA);
        a_a7.setEnabled(false);


        RGrp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.rb8) {
                    a_a7.setEnabled(true);
                    a_a7.setFocusableInTouchMode(true);

                }
                else{
                    a_a7.setEnabled(false);
                    a_a7.setFocusableInTouchMode(false);
                    a_a7.setText(null);
                }
            }


        });
    }

    public void Proceed(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to submit?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int id) {


                        int rbt1 = a_RB1.getCheckedRadioButtonId();
                        radioButton01 = findViewById(rbt1);
                        radioText = radioButton01.getText().toString();

                        int rbt2 = RGrp.getCheckedRadioButtonId();
                        radioButton02 = findViewById(rbt2);
                        radioText2 = radioButton02.getText().toString();

                         String Awareness_Activity_Completion = radioText;
                         String Activity_Performed_for_Awareness = radioText2;
                         String Activity_Audience = a_a3.getText().toString();
                         String Audience_Feedback = a_a4.getText().toString();
                         String Problems= a_a5.getText().toString();
                         String Suggestions = a_a6.getText().toString();
                         String type="awareness";
                         BackgroundWorker backgroundWorker = new BackgroundWorker(Awareness_Activity.this);

                        SharedPreferences sharedPreferences= PreferenceManager.getDefaultSharedPreferences(Awareness_Activity.this);
                        String ID = sharedPreferences.getString("ID","unknown");

                         backgroundWorker.execute(type, Awareness_Activity_Completion, Activity_Performed_for_Awareness, Activity_Audience, Audience_Feedback, Problems, Suggestions, ID);



                    }
                })

                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==GET_FROM_GALLERY && resultCode == Activity.RESULT_OK) {
            selectedImage = data.getData();
            try{
                Bitmap bitmap= MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                imageView.setImageBitmap(bitmap);

            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }




    public void openGallery(View view){

        startActivityForResult(new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.INTERNAL_CONTENT_URI), GET_FROM_GALLERY);


    }
}
