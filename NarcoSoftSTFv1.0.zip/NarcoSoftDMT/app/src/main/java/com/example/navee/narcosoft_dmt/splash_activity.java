package com.example.navee.narcosoft_dmt;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class splash_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        SharedPreferences pref= getSharedPreferences("ActivityPref", Context.MODE_PRIVATE);

        if (pref.getBoolean("activity_executed", false))
        {
            Intent i =new Intent(this,home_page.class);
            startActivity(i);
            finish();
        }
        else {
            Intent i =new Intent(this,MainActivity.class);
            startActivity(i);
            finish();
        }
    }
}