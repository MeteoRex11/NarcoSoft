package com.example.navee.narcosoft_nrnc;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;

public class info_page extends AppCompatActivity {

    int i=1;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info_page);

        ListView listView=findViewById(R.id.i_lv);
        customAapter customAapter=new customAapter();
        listView.setAdapter(customAapter);

    }

    class customAapter extends BaseAdapter {


        @Override
        public int getCount() {
            return 1;
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            view = getLayoutInflater().inflate(R.layout.identification_listview, null);

            return null;
        }
    }

}
