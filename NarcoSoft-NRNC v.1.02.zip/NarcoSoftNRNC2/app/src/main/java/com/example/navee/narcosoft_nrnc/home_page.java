package com.example.navee.narcosoft_nrnc;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class home_page extends AppCompatActivity {

    String NRNC="Snoop",NRNC_LOCATION="San Andreas";
    String User_1="Carl Johnson",Location_1="Grove St.";
    String User_2="Ryder",Location_2="Los Santos";
    String User_3="Big Smoke",Location_3="San Fierro";
    String User_4="USER 4",Location_4="Location 4";
    String User_5="USER 5",Location_5="Location 5";
    String User_6="USER 6",Location_6="Location 6";
    String User_7="USER 7",Location_7="Location 7";
    String User_8="USER 8",Location_8="Location 8";
    String User_9="USER 9",Location_9="Location 9";
    String User_10="USER 10",Location_10="Location 10";

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_page);
        SharedPreferences pref=getSharedPreferences("ActivityPref",MODE_PRIVATE);
        SharedPreferences.Editor edt =pref.edit();
        edt.putBoolean("activity_executed",true);
        edt.apply();
    }

    public void message_toast(View view){
        Toast msg=Toast.makeText(home_page.this,"Opening...",Toast.LENGTH_SHORT);
        msg.show();
        Intent i = new Intent(this,info_page.class);
        startActivity(i);
    }

    public void new_user(View view){
        Intent i = new Intent(this,MainActivity.class);
        startActivity(i);
        finish();
    }
}