package com.example.hunte.narcosoft_cc;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class dapo_list extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dapo_list);
    }

    public void info_page(View view)
    {
        Toast msg=Toast.makeText(dapo_list.this,"Opening...",Toast.LENGTH_SHORT);
        msg.show();

        Intent i = new Intent(this,info_page.class);
        startActivity(i);
    }
}
